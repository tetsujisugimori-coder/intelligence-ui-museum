const fs=require('fs'),path=require('path'),crypto=require('crypto'),cp=require('child_process');
const root=__dirname,src=path.join(root,'source'),{comparePair}=require('./source/classify.cjs');
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const original=path.join(root,'extracted/independent-13600858923');
const faults=[
['forged-cancellation',(a,b)=>{a.snapshot.events.find(e=>e.kind==='keydown-bubble').cancelled=false;}],
['alternate-close-request',(a,b)=>{for(const r of [a,b])r.snapshot.events.find(e=>e.kind==='close-request').owner='alternate';}],
['missing-focus-return',(a,b)=>{for(const r of [a,b])r.snapshot.events=r.snapshot.events.filter(e=>e.kind!=='focus-return');}],
['reversed-key-events',(a,b)=>{for(const r of [a,b]){let ev=r.snapshot.events;let i=ev.findIndex(e=>e.kind==='keydown-capture'),j=ev.findIndex(e=>e.kind==='keyup');[ev[i],ev[j]]=[ev[j],ev[i]];}}],
['substituted-png',(a,b,d)=>{fs.copyFileSync(path.join(d,'chromium-direct-1-delegated-open.png'),path.join(d,b.pngFile));b.pngSha256=hash(fs.readFileSync(path.join(d,b.pngFile)));}],
['row-source-mismatch',(a,b)=>{a.sourceSha256=b.sourceSha256='f'.repeat(64);}],
['reduced-denominator',(a,b,d,r)=>{r.rows=r.rows.slice(1);}],
['failure-forged-complete',(a,b)=>{b.status='COMPLETE';b.error='Error: runner execution failed';b.exitCode=1;}],
['measurement-drift',(a,b)=>{b.instrumentation='different';}],
['hidden-fallback',(a,b)=>{b.snapshot.config.fallback=true;}]
];
let out=[];
for(const [name,mut] of faults){const d=path.join(root,'fault-inputs',name);fs.mkdirSync(d,{recursive:true});for(const f of fs.readdirSync(original))fs.copyFileSync(path.join(original,f),path.join(d,f));
let r=JSON.parse(fs.readFileSync(path.join(d,'results.json'))),an='chromium-direct-1-controlled-cancel.json',bn='chromium-direct-1-controlled-plain.json',a=JSON.parse(fs.readFileSync(path.join(d,an))),b=JSON.parse(fs.readFileSync(path.join(d,bn)));mut(a,b,d,r);
fs.writeFileSync(path.join(d,an),JSON.stringify(a,null,2));fs.writeFileSync(path.join(d,bn),JSON.stringify(b,null,2));
let cmp=comparePair(a,b);r.pairs[0]={route:'direct',iteration:1,...cmp};fs.writeFileSync(path.join(d,'results.json'),JSON.stringify(r,null,2));
let manifest={};for(const f of fs.readdirSync(d).filter(f=>f!=='SHA256SUMS.json'))manifest[f]=hash(fs.readFileSync(path.join(d,f)));fs.writeFileSync(path.join(d,'SHA256SUMS.json'),JSON.stringify(manifest,null,2));
let exec=cp.spawnSync(process.execPath,[path.join(src,'audit.cjs'),d],{encoding:'utf8',env:{...process.env,MINIMAL_ENGINE:'chromium',MINIMAL_REPEATS:'2'}});fs.writeFileSync(path.join(root,`${name}.log`),exec.stdout+exec.stderr);
out.push({name,classification:cmp.classification,auditExit:exec.status,manifestHash:hash(fs.readFileSync(path.join(d,'SHA256SUMS.json'))),error:exec.stderr.slice(0,400)});
}
fs.writeFileSync(path.join(root,'fault-results-before.json'),JSON.stringify(out,null,2));console.log(JSON.stringify(out,null,2));
