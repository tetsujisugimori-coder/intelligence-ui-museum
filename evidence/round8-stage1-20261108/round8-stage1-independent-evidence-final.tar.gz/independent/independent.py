import zipfile,pathlib,hashlib,json, itertools
from PIL import Image,ImageChops
P=pathlib.Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
report=[]
for z in sorted((P/'original').glob('*.zip')):
 d=P/'extracted'/z.stem;d.mkdir(parents=True,exist_ok=True)
 with zipfile.ZipFile(z) as f:
  assert all('/' not in n for n in f.namelist());f.extractall(d)
 r=json.loads((d/'results.json').read_text());m=json.loads((d/'SHA256SUMS.json').read_text())
 assert set(m)=={f.name for f in d.iterdir() if f.name!='SHA256SUMS.json'}
 assert all(sha((d/n).read_bytes())==h for n,h in m.items())
 assert all(sha((P/'source'/n).read_bytes())==h for n,h in r['source'].items())
 expected=[f'{r["engine"]}-{route}-{i}-{case}' for route,i,case in itertools.product(['direct','tab'],[1,2],['controlled-cancel','controlled-plain','delegated-fallback','delegated-open','hook-cancel'])]
 assert [x['id'] for x in r['rows']]==expected
 rows={x['id']:json.loads((d/x['file']).read_text()) for x in r['rows']}
 assert all(x['status']=='COMPLETE' and x['errors']==[] and sha((d/x['pngFile']).read_bytes())==x['pngSha256'] for x in rows.values())
 assert all(x['sourceSha256']==r['source']['fixture.js'] for x in rows.values())
 for x in rows.values():
  im=Image.open(d/x['pngFile']);im.load();assert im.size==(x['pngClip']['width'],x['pngClip']['height'])
 pairs=[]
 for route,i in itertools.product(['direct','tab'],[1,2]):
  a,b=[rows[f'{r["engine"]}-{route}-{i}-{c}'] for c in ['controlled-cancel','controlled-plain']]
  sa,sb=a['snapshot'],b['snapshot']
  for s,cancel in [(sa,True),(sb,False)]:
   assert s['keydownCancelled']==cancel and s['preventCount']==int(cancel)
   assert s['open']==False and s['triggerFocused'] and s['value']=='a' and s['closeOwner']=='select-controlled'
   ev=s['events'];ks=[e['kind'] for e in ev]
   for k in ['keydown-capture','keyup','close-request','close-commit','focus-return','keydown-bubble']:assert ks.count(k)==1
   assert ks.index('keydown-capture')<ks.index('close-request')<ks.index('close-commit')<ks.index('focus-return')<ks.index('keyup')
   assert next(e for e in ev if e['kind']=='keydown-bubble')['cancelled']==cancel
  ia,ib=[Image.open(d/x['pngFile']).convert('RGB') for x in [a,b]]
  diff=ImageChops.difference(ia,ib);px=list(diff.getdata());w,h=ia.size
  changed=sum(p!=(0,0,0) for p in px)
  # fixture box has 16px margin. Outline lies in outer margin, offset4,width3.
  ring=sum(p!=(0,0,0) and (x<16 or x>=w-16 or y<16 or y>=h-16) for y in range(h) for x in range(w) for p in [px[y*w+x]])
  orange=lambda im:sum(abs(p[0]-198)<20 and abs(p[1]-106)<20 and abs(p[2]-32)<20 for p in im.getdata())
  pairs.append(dict(route=route,iteration=i,focus=[sa['focusVisible'],sb['focusVisible']],pngHashEqual=a['pngSha256']==b['pngSha256'],pixelsChanged=changed,outerMarginChanged=ring,bbox=diff.getbbox(),orangePixels=[orange(ia),orange(ib)],clip=[a['pngClip'],b['pngClip']]))
 report.append(dict(artifact=z.stem,zipSha256=sha(z.read_bytes()),files=len(m)+1,rows=len(rows),pngs=len(list(d.glob('*.png'))),platform=r['platform'],engine=r['engine'],node=r['node'],playwright=r['playwright'],pairs=pairs))
(P/'independent-results.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
