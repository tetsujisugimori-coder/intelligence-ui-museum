from pathlib import Path
import subprocess, hashlib, json, datetime
repo=Path(__file__).resolve().parents[1]/'independent-review'
def git(*a): return subprocess.check_output(['git',*a],cwd=repo)
def text(*a): return git(*a).decode().strip()
base='77d30ac54e35b8a6408fb5f56db4697adff8a452'
targets={'26':'f483d1c015378dbdce24a7680c8082cb3f898ab5','27':'f3893e50a020566b9a6aa2a66666a08108b89c07','23':'68743f6ff857e55f107ec6c1dc7b8e94b8d71511'}
protected=['legacy/v09','apps/v11','apps/v10/package.json','apps/v10/package-lock.json']
report={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':base,'targets':{}}
for pr,sha in targets.items():
 changes=text('diff','--name-only',base,sha).splitlines()
 item={'head':sha,'tree':text('rev-parse',sha+'^{tree}'),'changes':changes,'protectedChanges':{p:text('diff','--name-only',base,sha,'--',p).splitlines() for p in protected},'sourceHashes':{}}
 for p in ['apps/v10/src/main.tsx','apps/v10/src/main.css','apps/v10/package.json','apps/v10/package-lock.json']:
  data=git('show',sha+':'+p);item['sourceHashes'][p]=hashlib.sha256(data).hexdigest()
 report['targets'][pr]=item
for pr,component in [('26','tooltip-return'),('27','button-ring')]:
 p='evidence/s3-reaccept-20261106/independent/'+component+'/results.json'
 old=git('show',targets['23']+':'+p);new=git('show',targets[pr]+':'+p)
 report['targets'][pr]['originalRed']={'path':p,'identicalTo23':old==new,'blob':text('rev-parse',targets[pr]+':'+p),'sha256':hashlib.sha256(new).hexdigest(),'bytes':len(new)}
arc=git('show',targets['23']+':evidence/s3-reaccept-20261106/raw/independent-local.tar.gz')
report['originalArchive']={'sha256':hashlib.sha256(arc).hexdigest(),'bytes':len(arc)}
out=Path(__file__).with_name('preservation.json');out.write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
