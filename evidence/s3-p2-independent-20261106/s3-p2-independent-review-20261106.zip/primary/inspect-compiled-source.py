from pathlib import Path
import json,subprocess,hashlib
root=Path(__file__).resolve().parents[1];base=root/'independent-review/.work';out=[]
for component,head in {'tooltip':'aa20f218ac526a7c8a162324f6ecac2bd48991d1','button':'af38afb7524aeee24a7405c5d5db48152100bf00'}.items():
 expected=subprocess.check_output(['git','show',head+':apps/v10/src/main.tsx'],cwd=base/component).decode('utf-8')
 for p in (base/component/'.work/v10/dist/assets').glob('*.js.map'):
  j=json.loads(p.read_text(encoding='utf-8'));sources=[src for name,src in zip(j['sources'],j['sourcesContent']) if name.endswith('/main.tsx')]
  assert len(sources)==1 and sources[0]==expected
  out.append({'component':component,'head':head,'map':str(p),'mainSourceMatches':True,'mapSha256':hashlib.sha256(p.read_bytes()).hexdigest()})
assert len(out)==2
(root/'review-evidence/compiled-source-inspection.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out))
