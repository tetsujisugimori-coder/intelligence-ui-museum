from pathlib import Path
import zipfile,hashlib,json,shutil,datetime,re
root=Path(__file__).resolve().parents[1];own=root/'review-evidence';work=root/'independent-review/.work'
payload={}
def add(label,p):
 assert p.is_file(),p
 assert label not in payload,label
 payload[label]=p
for p in own.iterdir():
 if p.is_file():add('primary/'+p.name,p)
for component in ['tooltip','button']:
 d=work/component/'.work'
 for p in d.iterdir():
  if p.name.startswith('parent-'):
   if p.is_file():add('primary-browser/'+component+'/'+p.name,p)
   elif p.is_dir():
    for f in p.rglob('*'):
     if f.is_file():add('primary-browser/'+component+'/'+str(f.relative_to(d)).replace('\\','/'),f)
verify=work/'verify/.work'
for p in verify.iterdir():
 if p.name.startswith('parent-audit'):
  if p.is_file():add('primary-audit/'+p.name,p)
  else:
   for f in p.rglob('*'):
    if f.is_file():add('primary-audit/'+str(f.relative_to(verify)).replace('\\','/'),f)
nested={'tooltip.zip':work/'tooltip/.work/tooltip-independent-review-aa20f21.zip','button.zip':root/'button-independent-20261106.zip','audit-initial.zip':work/'integration/.work/c-independent-review-evidence.zip','integrated-windows.zip':work/'integration/.work/c-integrated-final-ea6f19a.zip','select-baseline.zip':work/'integration/.work/c-select-baseline77-supplement.zip'}
for name,p in nested.items():add('delegates/'+name,p)
add('delegates/tooltip-supplement.md',work/'tooltip/.work/tooltip-review-supplement.md')
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest={name:{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for name,p in sorted(payload.items())}
archive=root/'s3-p2-independent-review-20261106.zip';assert not archive.exists(),'fresh package required'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=True) as z:
 for name,p in sorted(payload.items()):
  z.write(p,name,compress_type=zipfile.ZIP_STORED if p.suffix=='.zip' else zipfile.ZIP_DEFLATED)
 z.writestr('EVIDENCE-MANIFEST.json',json.dumps({'sourceHeads':{'26':'aa20f218ac526a7c8a162324f6ecac2bd48991d1','27':'af38afb7524aeee24a7405c5d5db48152100bf00','23':'ea6f19acfd60b37e9b147daa92e79838fd2f3070'},'files':manifest},indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(manifest)+1
 for name,data in manifest.items():assert sha(z.read(name))==data['sha256'],name
result={'status':'PASS','reviewVerdict':'PARTIAL','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'zip':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'entries':len(manifest)+1,'internalHashes':len(manifest),'crcErrors':0,'hashMismatches':0,'sourceCompleteLinux':True,'sourceCompleteWindows':False,'mergeRecommendations':{'26':'YES','27':'YES','23':'NO'}}
assert result['bytes']<100*1024*1024
out=root/'delivery';out.mkdir(exist_ok=True)
for name,p in [('FINAL-REPORT.txt',own/'FINAL-REPORT.txt'),('SELECT-RESIDUAL-ISSUE-DRAFT.txt',own/'SELECT-RESIDUAL-ISSUE-DRAFT.txt')]:shutil.copyfile(p,out/name)
(out/'PACKAGE-INSPECTION.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
(out/'EVIDENCE-MANIFEST.json').write_text(json.dumps({'files':manifest},indent=2),encoding='utf-8')
print(json.dumps(result))
