from pathlib import Path
import zipfile, hashlib, json, zlib, struct
root=Path(__file__).resolve().parent
def png(data):
 pos=8; stream=b''; w=h=0
 while pos<len(data):
  n=struct.unpack('>I',data[pos:pos+4])[0]; typ=data[pos+4:pos+8]; payload=data[pos+8:pos+8+n]; pos+=12+n
  if typ==b'IHDR':
   w,h,depth,color,_,_,interlace=struct.unpack('>IIBBBBB',payload);assert depth==8 and color in (2,6) and interlace==0
  if typ==b'IDAT':stream+=payload
 channels=4 if color==6 else 3;stride=w*channels;raw=zlib.decompress(stream);out=bytearray();prev=bytearray(stride);p=0
 for y in range(h):
  f=raw[p];p+=1;row=bytearray(raw[p:p+stride]);p+=stride
  for x in range(stride):
   a=row[x-channels] if x>=channels else 0;b=prev[x];c=prev[x-channels] if x>=channels else 0
   if f==1:v=a
   elif f==2:v=b
   elif f==3:v=(a+b)//2
   elif f==4:
    q=a+b-c;pa=abs(q-a);pb=abs(q-b);pc=abs(q-c);v=a if pa<=pb and pa<=pc else b if pb<=pc else c
   elif f==0:v=0
   else:raise ValueError(f)
   row[x]=(row[x]+v)&255
  out.extend(row);prev=row
 return w,h,channels,out
report={'scope':'Existing author CI artifact bytes, not a fresh browser run','artifacts':{}}
for component in ['tooltip','button']:
 path=root/('author-'+component+'.zip');z=zipfile.ZipFile(path);j=json.loads(z.read('results.json'))
 item={'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size,'entries':len(z.namelist()),'crcError':z.testzip(),'reportedStatus':j['status'],'rows':len(j['rows'])}
 if component=='tooltip':
  item['uniqueRows']=len({(r['engine'],r['index']) for r in j['rows']});item['errors']=[r for r in j['rows'] if r['errors']]
 else:
  item['uniqueRows']=len({(r['engine'],r['id']) for r in j['rows']});item['pixels']=[]
  for r in j['rows']:
   imgs=[png(z.read(n)) for n in r['images']];assert len({x[:3] for x in imgs})==1
   w,h,c,_=imgs[0];sets=[]
   for a,b in [(imgs[0][3],imgs[1][3]),(imgs[2][3],imgs[3][3])]:
    sets.append({i//c for i in range(0,len(a),c) if max(abs(a[i+k]-b[i+k]) for k in range(3))>32})
   missing=sets[1]-sets[0]
   item['pixels'].append({'engine':r['engine'],'id':r['id'],'dimensions':[w,h],'rawChangedOriginal':len(sets[0]),'rawChangedUnclipped':len(sets[1]),'rawMissing':len(missing),'outline3offset4':r['geometry']['outlineWidth']==3 and r['geometry']['offset']==4})
 report['artifacts'][component]=item
(root/'author-artifact-inspection.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({k:{x:y for x,y in v.items() if x!='pixels'} for k,v in report['artifacts'].items()},indent=2))
