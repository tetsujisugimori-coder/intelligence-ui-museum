from pathlib import Path
import hashlib, subprocess, json, sys, datetime
repo=Path(sys.argv[1]).resolve(); out=Path(sys.argv[2]).resolve(); expected=sys.argv[3]
def git(*a): return subprocess.check_output(['git',*a],cwd=repo)
head=git('rev-parse','HEAD').decode().strip();assert head==expected,(head,expected)
files=['src/main.tsx','src/main.css','src/select-focus-return.ts','package.json','package-lock.json']
hash=lambda b:hashlib.sha256(b).hexdigest()
source={f:hash(git('show',head+':apps/v10/'+f)) for f in files}
working={f:hash((repo/'.work/v10'/f).read_bytes()) for f in files}
assert source==working,'prepared source differs from submitted HEAD'
dist=repo/'.work/v10/dist'; build={str(p.relative_to(dist)).replace('\\','/'):hash(p.read_bytes()) for p in sorted(dist.rglob('*')) if p.is_file()}
result={'submittedHead':head,'tree':git('rev-parse',head+'^{tree}').decode().strip(),'source':source,'preparedSource':working,'sourceExactMatch':True,'build':build,'scripts':{str(p.relative_to(repo)).replace('\\','/'):hash(p.read_bytes()) for p in (repo/'tests/s3-reaccept-independent').glob('*.cjs')},'boundAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'environment':'shared Windows host; fresh independent browser invocation; Playwright headless Chromium/WebKit, not real Safari/VoiceOver','resultDirectory':str(out)}
(out/'INDEPENDENT-IDENTITY.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps({'head':head,'sourceExactMatch':True,'buildFiles':len(build),'out':str(out)}))
