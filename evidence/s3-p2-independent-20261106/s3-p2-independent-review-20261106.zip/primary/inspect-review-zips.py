from pathlib import Path,PurePosixPath
import zipfile,json,hashlib,re
root=Path(__file__).resolve().parents[1];work=root/'independent-review/.work'
items=[('tooltip',work/'tooltip/.work/tooltip-independent-review-aa20f21.zip','da4c505e0ed011ee9515d26736a21135faadcfb897aceee890a5b39b9171268f'),('button',root/'button-independent-20261106.zip','c9df17fe272f14a62c4b8896496ccb9793bd80d68c00991003fe23f7466cdf09'),('audit-initial',work/'integration/.work/c-independent-review-evidence.zip','d3b2eeda3748cd3b48f3f4e17b1bdeb7223b749c8f8d77dceba0bffeb59d4e6a'),('integrated-windows',work/'integration/.work/c-integrated-final-ea6f19a.zip','06306fb0030f79dd5e89ce94f0e13ce64121353bf80bfe30106b0df89b56a978'),('select-baseline',work/'integration/.work/c-select-baseline77-supplement.zip','00d3578895e53a2f3f87b8539533d3f96eef8eb7be9dc006ae181b9efe9b2725')]
sha=lambda b:hashlib.sha256(b).hexdigest();reports=[]
for label,p,expected in items:
 z=zipfile.ZipFile(p);names=set(z.namelist());assert sha(p.read_bytes())==expected and z.testzip() is None
 assert all(not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts for n in names)
 manifests=[]
 for name in names:
  if not name.lower().endswith('.json') or not any(t in PurePosixPath(name).name.lower() for t in ['manifest','sha256']):continue
  try:j=json.loads(z.read(name))
  except (ValueError,UnicodeDecodeError):continue
  data=j.get('files',j) if isinstance(j,dict) else None
  if not isinstance(data,dict):continue
  hashes={k:(v.get('sha256') if isinstance(v,dict) else v) for k,v in data.items()}
  hashes={k:v for k,v in hashes.items() if isinstance(v,str) and re.fullmatch('[0-9a-f]{64}',v)}
  if not hashes:continue
  prefix=str(PurePosixPath(name).parent);prefix='' if prefix=='.' else prefix+'/'
  if not any(prefix+k in names or k in names for k in hashes):continue
  missing=[];bad=[]
  for f,h in hashes.items():
   key=prefix+f if prefix+f in names else f
   if key not in names:missing.append(f)
   elif sha(z.read(key))!=h:bad.append(f)
  assert not missing and not bad,(label,name,missing,bad)
  manifests.append({'name':name,'hashes':len(hashes),'missing':0,'mismatches':0})
 reports.append({'label':label,'path':str(p),'sha256':expected,'bytes':p.stat().st_size,'entries':len(names),'crcErrors':0,'checkedManifests':manifests})
out={'status':'PASS','reports':reports};(root/'review-evidence/review-zips-independent-inspection.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out))
