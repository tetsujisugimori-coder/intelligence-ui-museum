from pathlib import Path, PurePosixPath
import zipfile,hashlib,json,struct,zlib,subprocess
root=Path(__file__).resolve().parent;p=root/'ci-integrated-ea6f19a.zip';z=zipfile.ZipFile(p)
sha=lambda b:hashlib.sha256(b).hexdigest()
expected='886dc6f9f12d49bd109f9c2e7ef677c99a2cb9f7fad6961e54291cb8f13509de'
assert sha(p.read_bytes())==expected and z.testzip() is None
assert all(not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts for n in z.namelist())
base='s3-evidence/'
read=lambda f:json.loads(z.read(base+f))
manifest=read('manifest.json');missing=[];bad=[]
for f,h in manifest['files'].items():
 name=base+f
 if name not in z.namelist():missing.append(f)
 elif sha(z.read(name))!=h:bad.append(f)
assert not missing and not bad and manifest['complete'] is True
head='ea6f19acfd60b37e9b147daa92e79838fd2f3070';tree='4283ea61f64c6db2eda9fb0ff7c07f053e64406b'
identity=read('identity.json');matrix=read('matrix/results.json');focus=read('focus/results.json');faults=read('faults/results.json');steps=read('steps.json')
assert all(x['head']==head and x['tree']==tree for x in [manifest,identity,matrix])
repo=root.parent/'independent-review/.work/integration'
source={f:sha(subprocess.check_output(['git','show',head+':apps/v10/'+f],cwd=repo)) for f in ['src/main.tsx','src/main.css','src/select-focus-return.ts','package.json','package-lock.json']}
assert source==identity['source']==matrix['source']==focus['identity']
assert len(steps)==13 and all(s['exit']==0 and not s.get('signal') and not s.get('error') for s in steps)
assert matrix['status']=='PASS' and len(matrix['rows'])==32 and len({(r['engine'],r['width'],r['theme'],r['text']) for r in matrix['rows']})==32
assert all(r['status']=='PASS' and len(r['checks'])==9 and all(c['pass'] for c in r['checks']) and len(r['images'])==11 for r in matrix['rows'])
assert focus['status']=='PASS' and len(focus['rows'])==44 and len(focus['faults'])==14 and len(focus['regressions'])==4
assert faults['status']=='PASS' and len(faults['rows'])==6 and all(r['exit']==1 and not r.get('signal') and not r.get('error') and r['reasonMatched'] for r in faults['rows'])
audit=json.loads(z.read('s3-audit.json'));controls=json.loads(z.read('s3-audit-controls/results.json'))
assert audit['status']=='PASS' and controls['status']=='PASS' and len(controls['rows'])==12
assert all(r['reasonMatched'] and r['exit']==(0 if r['name']=='normal' else 1) for r in controls['rows'])
pngs=[]
for name in z.namelist():
 if not name.endswith('.png'):continue
 data=z.read(name);assert data[:8]==b'\x89PNG\r\n\x1a\n';pos=8;ended=False
 while pos<len(data):
  n=struct.unpack('>I',data[pos:pos+4])[0];typ=data[pos+4:pos+8];payload=data[pos+8:pos+8+n];crc=struct.unpack('>I',data[pos+8+n:pos+12+n])[0]
  assert zlib.crc32(typ+payload)&0xffffffff==crc,name
  if typ==b'IHDR':w,h=struct.unpack('>II',payload[:8]);assert w>0 and h>0
  pos+=n+12
  if typ==b'IEND':ended=True;break
 assert ended and pos==len(data),name
 pngs.append({'name':name,'width':w,'height':h})
result={'status':'PASS','kind':'actual complete Linux product CI evidence, independently inspected on Windows; not synthetic','artifactId':13513916245,'bytes':p.stat().st_size,'sha256':expected,'zipEntries':len(z.namelist()),'zipCrcErrors':0,'internalManifestHashes':len(manifest['files']),'missing':missing,'hashMismatches':bad,'head':head,'tree':tree,'sourceExactGitMatch':True,'sourceComplete':manifest['complete'],'stages':13,'matrix':32,'matrixImages':352,'focus':44,'focusFaults':14,'focusRegressions':4,'liveFaultKinds':6,'audit':audit,'auditControls':{'normalExit':0,'negativeExits':[r['exit'] for r in controls['rows'] if r['name']!='normal'],'count':12,'status':controls['status']},'pngFiles':len(pngs),'pngChunkCrcErrors':0}
(root/'ci-integrated-independent-inspection.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result))
