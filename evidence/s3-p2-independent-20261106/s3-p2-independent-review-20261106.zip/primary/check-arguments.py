from pathlib import Path
import subprocess,os,json
base=Path(__file__).resolve().parents[1]/'independent-review/.work'
cases=[('tooltip','0','chromium,webkit'),('tooltip','NaN','chromium,webkit'),('tooltip','Infinity','chromium,webkit'),('tooltip','-1','chromium,webkit'),('tooltip','1.5','chromium,webkit'),('tooltip','20','chromium,chromium'),('tooltip','20','invalid'),('button',None,'chromium,chromium'),('button',None,'invalid')]
rows=[]
for i,(component,repeats,engines) in enumerate(cases):
 env={**os.environ,'S3_ENGINES':engines}
 if repeats is not None:env['S3_REPEATS']=repeats
 p=subprocess.run(['node','tests/s3-reaccept-independent/'+('tooltip-return.cjs' if component=='tooltip' else 'button-ring.cjs')],cwd=base/component,env=env,capture_output=True,text=True)
 stem=f'argument-{i}-{component}'
 Path(__file__).with_name(stem+'.stdout.log').write_text(p.stdout,encoding='utf-8');Path(__file__).with_name(stem+'.stderr.log').write_text(p.stderr,encoding='utf-8')
 reason='positive safe integer' if component=='tooltip' else 'supported and unique'
 rows.append({'component':component,'repeats':repeats,'engines':engines,'exit':p.returncode,'expectedReason':reason,'pass':p.returncode==1 and reason in p.stderr})
result={'status':'PASS' if all(r['pass'] for r in rows) else 'FAIL','rows':rows}
Path(__file__).with_name('argument-validation.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result))
