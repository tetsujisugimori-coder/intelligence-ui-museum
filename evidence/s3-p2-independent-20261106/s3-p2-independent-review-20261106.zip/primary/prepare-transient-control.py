from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent; src=root/'tooltip-rapid.cjs'
text=src.read_text(encoding='utf-8')
old='await p.goto(url,{waitUntil:"domcontentloaded"});await p.bringToFront()'
injection='''await p.addInitScript(()=>{document.addEventListener('focusin',e=>{if(e.target.matches?.('#Tooltip .stage button')){window.__faultFocus=(window.__faultFocus||0)+1;if(window.__faultFocus===2){let n=0;const tick=()=>{if(++n===12){const style=document.createElement('style');style.textContent='[data-radix-popper-content-wrapper],[role="tooltip"]{visibility:hidden!important}';style.id='independent-transient-fault';document.head.append(style);}else requestAnimationFrame(tick)};requestAnimationFrame(tick)}}},true)});'''
assert text.count(old)==1
text=text.replace(old,injection+old)
dst=root/'tooltip-transient-control.cjs';dst.write_text(text,encoding='utf-8')
(root/'transient-control-provenance.json').write_text(json.dumps({'positiveRunnerSha256':hashlib.sha256(src.read_bytes()).hexdigest(),'negativeRunnerSha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'fault':'After second focus (keyboard return), hide actual tooltip on frame12, after an initial visible period. Product and SDK files unchanged.','expected':'real focus retained, initial visible and subsequent hidden samples; returnPass=false; process exit1; no pageerror'},indent=2),encoding='utf-8')
print(dst)
