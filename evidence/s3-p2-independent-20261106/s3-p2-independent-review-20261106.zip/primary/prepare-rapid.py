from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
src=root.parent/'independent-review/.work/tooltip/tests/s3-reaccept-independent/review-tooltip.cjs'
text=src.read_text(encoding='utf-8')
old='await t.evaluate(element=>element.scrollIntoView({block:"center"}));await settle(p);await t.focus()'
new='await t.scrollIntoViewIfNeeded();await settle(p);await t.focus()'
assert text.count(old)==1
text=text.replace(old,new)
old="await p.keyboard.press('Tab');await tip.waitFor({state:'hidden',timeout:2000});await frame(p);await p.keyboard.press('Shift+Tab');row.returnSamples=[]"
new="await p.keyboard.press('Tab');await p.keyboard.press('Shift+Tab');row.returnSamples=[]"
assert text.count(old)==1
text=text.replace(old,new)
text='// Independent reconstruction of rapid Tab/wheel diagnostic, NOT the missing initial-run snapshot.\n'+text
dst=root/'tooltip-rapid.cjs';dst.write_text(text,encoding='utf-8')
(root/'rapid-provenance.json').write_text(json.dumps({'purpose':'fresh matched old/new rapid diagnostic; initial exploratory runner snapshot was not retained','inputSha256':hashlib.sha256(src.read_bytes()).hexdigest(),'runnerSha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'changes':['scrollIntoViewIfNeeded instead of centered initial scroll','Tab immediately followed by Shift+Tab, without hidden/frame wait'],'otherChecks':'20 double-rAF samples, 8 stable double-rAF frames, 5 rapid Tab/ShiftTab/wheel cycles, blur, Escape, hover, ARIA; pointer controls unchanged'},indent=2),encoding='utf-8')
print(dst)
