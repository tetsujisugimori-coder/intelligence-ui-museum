const fs=require('fs'),crypto=require('crypto');const old=require('./attack-before/compare.cjs'),fixed=require('./attack-after/compare.cjs');const dir='/workspace/shared/intelligence-round8-sdk/evidence/controlled-chromium-3/';const base=['paired-cancel','paired-plain'].map(c=>JSON.parse(fs.readFileSync(dir+'pilot-detail-direct-1-'+c+'.json')));const out=[];
for(const [name,fn] of [
 ['missing-dom-css',(a,b)=>{for(const x of [a,b]){delete x.before.cssHash;delete x.before.triggerOuterHTML}}],
 ['close-before-Escape',(a,b)=>{for(const x of [a,b]){const es=x.result.events,i=es.findIndex(e=>e.kind==='react-close-request'&&e.nextState===false),e=es.splice(i,1)[0];es.unshift(e);es.forEach((e,i)=>{e.seq=i+1;e.time=i})}}],
 ['keydown-final-before-keydown',(a,b)=>{for(const x of [a,b]){const es=x.result.events,i=es.findIndex(e=>e.kind==='keydown-final'),e=es.splice(i,1)[0];es.unshift(e);es.forEach((e,i)=>{e.seq=i+1;e.time=i})}}],
 ['missing-observer',(a,b)=>{for(const x of [a,b])x.result.events=x.result.events.filter(e=>!['observer-dom','museum-observer'].includes(e.kind))}],
 ['null-event-clock',(a,b)=>{for(const x of [a,b])x.result.events.forEach(e=>{e.seq=null;e.time=null})}],
 ['stack-before-cancellation-contradiction',(a,b)=>{for(const x of [a,b])x.result.events.find(e=>e.kind==='stack-before').cancelled=!x.result.events.find(e=>e.kind==='stack-after').cancelled}],
 ['failure-exit-code',(a,b)=>{b.exitCode=1}],
 ['inconsistent-select-transition',(a,b)=>{a.result.events.find(e=>e.kind==='select-escape-before').cancelled=true}]
]){const p=JSON.parse(JSON.stringify(base));fn(...p);const before=old.compare(...p),r=fixed.compare(...p);const data=JSON.stringify(p,null,2);fs.writeFileSync(__dirname+'/attack-after/'+name+'.json',data);out.push({name,before:before.classification,classification:r.classification,errors:r.errors,inputSha256:crypto.createHash('sha256').update(data).digest('hex')})}
fs.writeFileSync(__dirname+'/attack-after/results.json',JSON.stringify(out,null,2));console.log(JSON.stringify(out,null,2));
