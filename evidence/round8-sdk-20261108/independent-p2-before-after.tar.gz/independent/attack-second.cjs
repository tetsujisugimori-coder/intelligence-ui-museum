const fs=require('fs'),crypto=require('crypto'),{compare}=require('/workspace/shared/intelligence-round8-sdk/tests/sdk-parity/compare.cjs');const dir='/workspace/shared/intelligence-round8-sdk/evidence/controlled-chromium-3/';const base=['paired-cancel','paired-plain'].map(c=>JSON.parse(fs.readFileSync(dir+'pilot-detail-direct-1-'+c+'.json')));const out=[];fs.mkdirSync(__dirname+'/attack-second',{recursive:true});
for(const [name,fn]of[
 ['select-after-before-keydown',(a,b)=>{for(const r of [a,b]){const es=r.result.events,i=es.findIndex(e=>e.kind==='select-escape-after');es.unshift(es.splice(i,1)[0]);es.forEach((e,i)=>{e.seq=i+1;e.time=i})}}],
 ['stack-after-before-keydown',(a,b)=>{for(const r of [a,b]){const es=r.result.events,i=es.findIndex(e=>e.kind==='stack-after');es.unshift(es.splice(i,1)[0]);es.forEach((e,i)=>{e.seq=i+1;e.time=i})}}],
 ['cancel-after-keyup',(a,b)=>{const es=a.result.events,i=es.findIndex(e=>e.kind==='cancel-call');es.push(es.splice(i,1)[0]);es.forEach((e,i)=>{e.seq=i+1;e.time=i})}],
 ['missing-react-commit',(a,b)=>{for(const r of [a,b])r.result.events=r.result.events.filter(e=>e.kind!=='react-layout-after-commit')}],
 ['callsite-spoof',(a,b)=>{for(const r of [a,b])for(const e of r.result.events)if(e.source)e.source='other-source';}]
]){const p=JSON.parse(JSON.stringify(base));fn(...p);const data=JSON.stringify(p,null,2);fs.writeFileSync(__dirname+'/attack-second/'+name+'.json',data);out.push({name,...compare(...p),hash:crypto.createHash('sha256').update(data).digest('hex')})}
fs.writeFileSync(__dirname+'/attack-second/results.json',JSON.stringify(out,null,2));console.log(out.map(r=>({name:r.name,classification:r.classification,errors:r.errors})))
