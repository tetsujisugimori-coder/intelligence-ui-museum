const fs=require('fs'),crypto=require('crypto');const {compare}=require('./attack-before/compare.cjs'),base=require('./attack-before/test-pair.json');const out=[];
for(const [name,fn] of [
 ['missing-dom-css',(a,b)=>{for(const x of [a,b]){delete x.before.cssHash;delete x.before.triggerOuterHTML}}],
 ['close-before-Escape',(a,b)=>{for(const x of [a,b]){const es=x.result.events,i=es.findIndex(e=>e.kind==='react-close-request'&&e.nextState===false),e=es.splice(i,1)[0];es.unshift(e);es.forEach((e,i)=>{e.seq=i+1;e.time=i})}}],
 ['keydown-final-before-keydown',(a,b)=>{for(const x of [a,b]){const es=x.result.events,i=es.findIndex(e=>e.kind==='keydown-final'),e=es.splice(i,1)[0];es.unshift(e);es.forEach((e,i)=>{e.seq=i+1;e.time=i})}}],
 ['missing-observer',(a,b)=>{for(const x of [a,b])x.result.events=x.result.events.filter(e=>!['observer-dom','museum-observer'].includes(e.kind))}],
 ['null-event-clock',(a,b)=>{for(const x of [a,b])x.result.events.forEach(e=>{e.seq=null;e.time=null})}],
 ['stack-before-cancellation-contradiction',(a,b)=>{for(const x of [a,b])x.result.events.find(e=>e.kind==='stack-before').cancelled=!x.result.events.find(e=>e.kind==='stack-after').cancelled}],
 ['failure-exit-code',(a,b)=>{b.exitCode=1}],
 ['inconsistent-select-transition',(a,b)=>{a.result.events.find(e=>e.kind==='select-escape-before').cancelled=true}]
]){const p=JSON.parse(JSON.stringify(base));fn(...p);const r=compare(...p);const data=JSON.stringify(p,null,2);fs.writeFileSync(__dirname+'/attack-before/'+name+'.json',data);out.push({name,classification:r.classification,errors:r.errors,inputSha256:crypto.createHash('sha256').update(data).digest('hex')})}
fs.writeFileSync(__dirname+'/attack-before/results.json',JSON.stringify(out,null,2));console.log(JSON.stringify(out,null,2));
