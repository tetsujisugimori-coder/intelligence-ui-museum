'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const {validate,compare}=require('./compare.cjs'),{outlinePixels}=require('./png.cjs'),plan=require('./plan.json');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
function audit(dir){const read=f=>JSON.parse(fs.readFileSync(path.join(dir,f))),r=read('results.json'),manifest=read('SHA256SUMS.json');
 assert.deepEqual(r.plan,plan,'fixed plan');assert.equal(r.scope,plan.scope);assert.ok(['chromium','webkit'].includes(r.engine));assert.ok(!r.fatal,'fatal runner');
 assert.deepEqual(Object.keys(manifest).sort(),fs.readdirSync(dir).filter(f=>f!=='SHA256SUMS.json').sort(),'inventory');for(const [f,h]of Object.entries(manifest)){assert.equal(f,path.basename(f));assert.equal(sha(fs.readFileSync(path.join(dir,f))),h,'manifest '+f);}
 assert.deepEqual(Object.keys(r.sources).sort(),fs.readdirSync(__dirname).filter(f=>/\.(cjs|mjs|tsx|css|json)$/.test(f)).sort(),'source inventory');
 for(const m of plan.measurements)assert.equal(sha(r.buildFiles[m].map(f=>f+':'+sha(fs.readFileSync(path.join(dir,m+'-asset-'+f)))).join('\n')),r.builds[m],'build assets');
 for(const [f,h]of Object.entries(r.sources)){assert.equal(f,path.basename(f));assert.equal(sha(fs.readFileSync(path.join(__dirname,f))),h,'source '+f);}assert.equal(sha(JSON.stringify(r.sources)),r.sourceHash);
 const expected=[];for(const m of plan.measurements)for(const route of plan.routes)for(let i=1;i<=plan.pilotRepeats;i++)for(const c of ['native',...(i%2?plan.pairConditions:[...plan.pairConditions].reverse())])expected.push(['pilot',m,route,i,c].join('-'));
 if(r.formalExpanded)for(const route of plan.routes)for(let i=1;i<=plan.formalRepeats;i++)for(const c of i%2?plan.pairConditions:[...plan.pairConditions].reverse())expected.push(['formal','detail',route,i,c].join('-'));
 assert.deepEqual(r.rows.map(x=>x.id),expected,'planned denominator/order');
 const rows=r.rows.map(x=>{assert.equal(x.file,x.id+'.json');const a=read(x.file);assert.equal(a.id,x.id);assert.equal(a.id,[a.phase,a.measurement,a.route,a.iteration,a.condition].join('-'),'internal identity');assert.equal(a.engine,r.engine);assert.equal(a.sourceHash,r.sourceHash);assert.equal(a.buildHash,r.builds[a.measurement]);assert.equal(a.status,x.status);assert.deepEqual(validate(a),[],'row validation '+a.id);assert.equal(a.pngFile,a.id+'.png');const png=fs.readFileSync(path.join(dir,a.pngFile));assert.equal(sha(png),a.pngSha256);assert.deepEqual(outlinePixels(png),a.pixels,'decoded pixels');assert.equal(a.pixels.width,a.pngClip.width);assert.equal(a.pixels.height,a.pngClip.height);return a;});
 const derive=phase=>rows.filter(a=>a.phase===phase&&a.measurement==='detail'&&a.condition==='paired-cancel').map(a=>({route:a.route,iteration:a.iteration,...compare(a,rows.find(b=>b.phase===a.phase&&b.measurement===a.measurement&&b.route===a.route&&b.iteration===a.iteration&&b.condition==='paired-plain'))}));
 const pp=derive('pilot');assert.deepEqual(pp,r.pilotPairs);assert.deepEqual(derive('formal'),r.formalPairs);
 const neutral=[];for(const route of plan.routes)for(const c of plan.pilotConditions)for(let i=1;i<=plan.pilotRepeats;i++){const a=plan.measurements.map(m=>rows.find(x=>x.phase==='pilot'&&x.measurement===m&&x.route===route&&x.iteration===i&&x.condition===c));if(a.some(x=>!x||x.status!=='COMPLETE'))neutral.push('incomplete');else if(new Set(a.map(x=>JSON.stringify([x.result.focused,x.result.focusVisible,x.result.value,x.result.popupPresent,x.pixels.outlineEstimate]))).size!==1)neutral.push([route,c,i].join('-'));}
 assert.deepEqual(neutral,r.neutrality);assert.equal(r.formalExpanded,pp.length===4&&pp.every(p=>p.classification==='COMPARABLE_WITH_COMMON_INTERVENTIONS')&&!neutral.length,'expansion gate');
 if(r.formalExpanded)assert.ok(r.formalPairs.every(p=>p.classification==='COMPARABLE_WITH_COMMON_INTERVENTIONS'),'formal comparison');
 for(const m of plan.measurements){const p=read('source-'+m+'.json');assert.equal(p.mode,m);assert.ok(p.records.some(x=>x.file.endsWith('/components/Select/Select.js')));for(const s of p.records){assert.equal(sha(s.original),s.before);assert.equal(sha(s.transformed),s.after);}}
 return {rows:rows.length,pilotPairs:pp.length,formalPairs:r.formalPairs.length,formalExpanded:r.formalExpanded,neutrality:neutral,unalteredSdkCausality:'UNKNOWN'};
}
module.exports={audit};if(require.main===module)console.log(JSON.stringify(audit(path.resolve(process.argv[2]))));
