'use strict';
const assert=require('node:assert/strict');
const invariantKeys=['engine','route','iteration','measurement','phase','buildHash','sourceHash'];
function validate(row){const e=[];const r=row?.result;
 if(row?.status!=='COMPLETE'||!Array.isArray(row.errors)||row.errors.length||row.error)e.push('execution');
 if(!['chromium','webkit'].includes(row?.engine)||!['direct','tab'].includes(row?.route)||!['none','minimal','detail'].includes(row?.measurement)||!['pilot','formal'].includes(row?.phase)||!Number.isInteger(row?.iteration)||row.iteration<1)e.push('identity');
 for(const k of ['buildHash','sourceHash'])if(!/^[a-f0-9]{64}$/.test(row?.[k]||''))e.push('hash:'+k);
 if(!['native','paired-cancel','paired-plain'].includes(row?.condition))e.push('condition');
 if(!r||r.expanded!=='false'||r.popupPresent!==false||r.focused!==true||r.value!=='a'||r.pageErrors!==0)e.push('closed-value-focus');
 if(!row?.before?.popupPresent||row.before.expanded!=='true')e.push('popup-not-opened');
 if(row?.measurement==='detail'){
 const es=r?.events||[],get=k=>es.filter(x=>x.kind===k),ix=k=>es.findIndex(x=>x.kind===k);
 for(const k of ['keydown','keyup','keydown-final','radix-escape','select-escape-before','select-escape-after','radix-fallback-gate','stack-before','stack-after','esc-stack-close','museum-focus-return'])if(get(k).length!==1)e.push('event-count:'+k);
 if(get('radix-fallback').length)e.push('fallback');
 const close=get('react-close-request').filter(x=>x.nextState===false);
 if(close.length!==1)e.push('close-count');
 if(!(ix('keydown')<ix('radix-escape')&&ix('radix-escape')<ix('select-escape-before')&&ix('select-escape-before')<ix('stack-before')&&ix('stack-before')<ix('esc-stack-close')&&ix('esc-stack-close')<ix('museum-focus-return')&&ix('museum-focus-return')<ix('keyup')&&ix('keydown-final')<ix('keyup')))e.push('event-order');
 if(es.some((x,i)=>i>0&&(x.seq<=es[i-1].seq||x.time<es[i-1].time)))e.push('time-sequence');
 const yes=row.condition!=='paired-plain',calls=get('cancel-call');
 if(get('keydown-final')[0]?.cancelled!==yes||get('select-escape-after')[0]?.cancelled!==yes||get('stack-after')[0]?.cancelled!==yes||calls.length!==(row.condition==='native'?2:yes?1:0))e.push('cancellation');
 if(row.condition!=='native'&&calls.some(x=>x.owner!=='select'))e.push('cancel-origin');
 if(get('keydown')[0]?.trusted!==true||get('keyup')[0]?.trusted!==true)e.push('untrusted');
 if(row.condition!=='native'&&get('radix-fallback-gate')[0]?.suppressed!==true)e.push('fallback-gate');
 }
 return e;
}
function compare(a,b){const errors=[...validate(a).map(x=>'A:'+x),...validate(b).map(x=>'B:'+x)];
 if(a?.condition!=='paired-cancel'||b?.condition!=='paired-plain')errors.push('pair');
 for(const k of invariantKeys)if(a?.[k]!==b?.[k]||a?.[k]==null)errors.push('provenance:'+k);
 for(const k of ['triggerOuterHTML','cssHash'])if(a?.before?.[k]!==b?.before?.[k])errors.push('DOM-CSS:'+k);
 if(a?.measurement!=='detail'||b?.measurement!=='detail')errors.push('callsite-not-observed');
 const skeleton=r=>(r?.result?.events||[]).filter(e=>!['cancel-call','observer-dom','focusin','museum-observer'].includes(e.kind)).map(e=>[e.kind,e.nextState??null]);
 if(JSON.stringify(skeleton(a))!==JSON.stringify(skeleton(b)))errors.push('closure-path');
 return {scope:'COMMON_INTERVENTION_SDK_ONLY',classification:errors.length?'NOT_COMPARABLE':'COMPARABLE_WITH_COMMON_INTERVENTIONS',unalteredSdkCausality:'UNKNOWN',errors,outcomes:{focusVisible:[a?.result?.focusVisible,b?.result?.focusVisible],pngHashEqual:a?.pngSha256===b?.pngSha256}};
}
module.exports={validate,compare};
