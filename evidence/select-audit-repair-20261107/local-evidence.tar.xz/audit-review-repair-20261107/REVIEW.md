# Independent repair review, first candidate

Reviewed 2026-11-07 18:15 JST. HEAD remains 8e52ebe049a74abf9f6a9f91f855a12488980f32; four diagnostic files were uncommitted. Frozen reviewed source snapshots are in this directory. This report is not approval of any later revisions.

## Results

- Independently ran the submitted 68 tests: 68 passed, exit 0.
- Independently ran pinned Playwright Chromium exact/legacy 375/light/100 once, using the provided existing browser directory. The original child returned exit 1 and product suite FAIL; wrapper returned COMPLETE/exit 0, traceValid true, and explicit NOT_TESTED for the blocked disabled Select force-click and subsequent assertions. Valid Node-side receipt was written with source line 84, column 2074. This is diagnostic completion, not full product suite acceptance.
- Independently ran 39 fixture cases against both the frozen audit module and frozen wrapper. Each fixture clones actual repaired live evidence, mutates identified fields, and recomputes a coherent manifest so semantic validation is exercised rather than all cases being rejected merely for a stale hash. Browser spawn alone is stubbed in these tests. Results: 29 INCOMPLETE/exit1; two uncaught wrapper TypeErrors; eight COMPLETE/exit0 including one positive control. JSON inputs, receipts, copied evidence and outcomes are preserved.
- All central baseline P1 cases are now rejected: failed prefix/Tooltip/errors checks, missing/type-invalid pass, duplicate or missing checks, row.error, unexpected-console classification, sentinel substring impostor, absent Select paint, Select string pass, status/exit contradiction, null row/check, and invalid checks container.
- Additional evidence tests: an altered raw result without rehash is rejected; missing screenshot is rejected; historical raw evidence lacking receipt remains unverified/rejected.

## Remaining findings

### P2: Malformed console/images still throw before wrapper outcome is saved

`audit` uses c.classification without guarding null entries. `row.console=[null]` throws TypeError. `policyStopValid` calls row.images?.includes while only checking the separate paint.images array; row.images={} throws TypeError. Both prevent third-results.json from being produced. These are not false-success cases, but the promised malformed-record diagnosis is incomplete. Validate these containers before property/method access.

### P2: Policy receipt callsite is asserted, not independently checked

Changing only receipt.callsite.line to 1, or column to 1, while retaining matched:true yields COMPLETE/exit0 with a coherent manifest. Those coordinates cannot be the known source callsite. The audit should compare the receipt coordinates with the exact known runner source, rather than treating a positive integer and matched flag as sufficient proof. A per-run Node nonce would also bind a receipt to this invocation, not merely the same source hash and page index. Receipt recordedAt missing or 1900 also passes; this demonstrates no time/run binding, not an actual browser malfunction.

### P2: Select paint file references may point at non-images

Replacing Select paint.images with results.json, third-policy-1.json, third-trace-1.json and a Button PNG, also including them in row.images, yields COMPLETE/exit0. Exact expected row-id-based Select image names and manifest presence would reject this cheap substitution. This is a coherently modified fixture, not a claim that the preserved original runner emits such data.

### P3: Known-font console classification is trusted

Adding a non-CSP exception but setting classification:'known-font-CSP' produces COMPLETE/exit0. A semantic verifier can cross-check message structure and matching CSP records. As with other coherent evidence mutations, a manifest is an integrity consistency check, not cryptographic authentication. No arbitrary forged bundle can be made authentic merely by additional self-reported fields.

### P3 / scope note: Empty original row events and prior trace schema weakness

Removing original row.events still completes when the separate full third trace remains intact. That is not necessarily invalid for the minimal lane, which deliberately omits original listeners. No universal nonempty-row.events rule is recommended. The previously noted trace final-schema weakness is unchanged; do not equate trace presence checks with product acceptance.

## Limits

No product/SDK/lock/history edit, publish, merge or force click was performed by the reviewer. No fixed sleep was used. Live test coverage is one Chromium exact/legacy condition only; no independent WebKit, Windows, 20-run matrix, broader browser matrix or product acceptance run. The two earlier browser setup failures remain preserved in the baseline directory and are not overwritten by this successful pinned-browser run.
