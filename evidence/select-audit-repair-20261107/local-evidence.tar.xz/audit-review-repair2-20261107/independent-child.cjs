'use strict';
// Synthetic replay; never represents a fresh browser run. Rebind only HEAD/tree and invocation nonce.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{execFileSync}=require('node:child_process');
const dest=process.env.EVIDENCE_DIR,repo=path.resolve(__dirname,'../..');
fs.cpSync(process.env.REVIEW_FIXTURE,dest,{recursive:true});
const result=JSON.parse(fs.readFileSync(path.join(dest,'results.json')));
result.head=execFileSync('git',['rev-parse','HEAD'],{cwd:repo,encoding:'utf8'}).trim();result.tree=execFileSync('git',['rev-parse','HEAD^{tree}'],{cwd:repo,encoding:'utf8'}).trim();
fs.writeFileSync(path.join(dest,'results.json'),JSON.stringify(result,null,2));
const rp=path.join(dest,'third-policy-1.json');if(fs.existsSync(rp)){const r=JSON.parse(fs.readFileSync(rp));r.runToken=process.env.THIRD_RUN_TOKEN;fs.writeFileSync(rp,JSON.stringify(r,null,2));}
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');fs.writeFileSync(path.join(dest,'SHA256SUMS.json'),JSON.stringify(Object.fromEntries(fs.readdirSync(dest).filter(f=>f!=='SHA256SUMS.json').map(f=>[f,sha(fs.readFileSync(path.join(dest,f)))])),null,2));
process.exitCode=process.env.REVIEW_CHILD_EXIT==='0'?0:1;
