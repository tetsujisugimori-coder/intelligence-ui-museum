'use strict';
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),cp=require('node:child_process'),crypto=require('node:crypto');
const dir=__dirname,repo=path.resolve(dir,'../..'),auditor=require('./third-audit.cjs');
const rawDir=path.join(dir,'live-chromium-legacy/run-01');
const raw=JSON.parse(fs.readFileSync(path.join(rawDir,'results.json'))),receipt=JSON.parse(fs.readFileSync(path.join(rawDir,'third-policy-1.json')));
const sha=b=>crypto.createHash('sha256').update(b).digest('hex'),expected={head:raw.head,tree:raw.tree,runner:raw.runner,source:raw.source,ids:raw.rows.map(x=>x.id),runToken:receipt.runToken,policyCallsite:auditor.policyCallsite(fs.readFileSync(path.join(repo,'tests/select-webkit-timeline/original-browser.cjs'),'utf8').replace("(fault?[1280]:[320,375,390,1280])","[375]").replace("(fault?['light']:['light','dark'])","['light']").replace("(fault?[100]:[100,200])","[100]").replace("*(fault?1:16)","*1"))};
const check=(r,n)=>r.rows[0].checks.find(c=>c.name===n),noop=()=>{};
const cases=[['control-policy-stop',noop],
 ...['environment','layout','Button','Badge','Alert','Switch','Tooltip','errors'].map(n=>['failed-'+n,r=>{check(r,n).pass=false;check(r,n).error='Error: injected '+n+' failure';delete check(r,n).detail;}]),
 ['missing-pass',r=>{delete check(r,'Button').pass;}],['string-pass',r=>{check(r,'Switch').pass='false';}],
 ...['Select','Tooltip','errors'].map(n=>['missing-'+n,r=>{r.rows[0].checks=r.rows[0].checks.filter(c=>c.name!==n);}]),
 ['duplicate-check',r=>{r.rows[0].checks.push({name:'Button',pass:false,error:'duplicate failure'});}],
 ['row-error',r=>{r.rows[0].error='Error: finally failed';}],
 ['unexpected-console',r=>{r.rows[0].console.push({classification:'unexpected',message:'unexpected exception'});check(r,'errors').pass=false;check(r,'errors').error='Error: unexpected console error';}],
 ['policy-substring-impostor',r=>{check(r,'Select').error='TimeoutError: text THIRD_POLICY_FORCED_CLICK_NOT_TESTED timeout';}],
 ['policy-no-paint',r=>{delete r.rows[0].selectPaint;}],
 ['policy-empty-events',r=>{r.rows[0].events=[];}],
 ['select-string-pass',r=>{check(r,'Select').pass='false';check(r,'Select').error='Error: Select real failure';}],
 ['status-contradiction',r=>{r.status='PASS';r.rows[0].status='PASS';}],
 ['exit-zero-contradiction',noop,noop,0],
 ['null-row',r=>{r.rows=[null];}],['null-check',r=>{r.rows[0].checks.push(null);}],['wrong-checks-type',r=>{r.rows[0].checks={};}],
 ['null-console',r=>{r.rows[0].console.push(null);}],['wrong-images-type',r=>{r.rows[0].images={};}],
 ['null-receipt',noop,p=>null],['wrong-receipt-page',noop,p=>({...p,page:2})],['wrong-receipt-runner',noop,p=>({...p,runnerHash:'0'.repeat(64)})],
 ['wrong-receipt-selector',noop,p=>({...p,selector:'#Button'})],['wrong-receipt-options',noop,p=>({...p,options:{force:true,timeout:1}})],
 ['wrong-receipt-callsite-line',noop,p=>({...p,callsite:{...p.callsite,line:1}})],
 ['wrong-receipt-callsite-column',noop,p=>({...p,callsite:{...p.callsite,column:1}})],
 ['stale-receipt-time',noop,p=>({...p,recordedAt:'1900-01-01T00:00:00Z'})],
 ['missing-receipt-time',noop,p=>{delete p.recordedAt;return p;}],
 ['misclassified-console',r=>{r.rows[0].console.push({classification:'known-font-CSP',message:'Unexpected non-CSP exception'});}],
 ['policy-paint-images-not-screenshots',r=>{r.rows[0].selectPaint.images=['results.json','third-policy-1.json','third-trace-1.json','chromium-375-light-100-Button-on.png'];r.rows[0].images.push(...r.rows[0].selectPaint.images);}],
 ];
const summary=[];
for(const [name,mutate,mutateReceipt=noop,status=1] of cases){const r=structuredClone(raw);mutate(r);let p=structuredClone(receipt);const mutated=mutateReceipt(p);if(mutateReceipt!==noop)p=mutated;
 const d=path.join(dir,'case-'+name);fs.mkdirSync(d);fs.writeFileSync(path.join(d,'raw-input.json'),JSON.stringify(r,null,2));fs.writeFileSync(path.join(d,'receipt-input.json'),JSON.stringify(p,null,2));
 let direct;try{direct={reasons:auditor.audit(r,expected,{status},[p])};}catch(e){direct={threw:String(e)};}
 const processMock={env:{...process.env,THIRD_LANE:'exact',THIRD_ENGINE:'chromium',THIRD_FOCUS:'legacy',THIRD_REPEATS:'1',THIRD_OUT:path.join(d,'wrapper'),APP_ROOT:path.join(repo,'.work/v10')},execPath:process.execPath,version:process.version};
 const stdout=[];const fsProxy=new Proxy(fs,{get(t,k){if(k==='writeFileSync'||k==='unlinkSync')return (f,...args)=>t[k](String(f).includes('/.third-generated-')?path.join(d,path.basename(f)):f,...args);return t[k];}});
 const childProxy={...cp,spawnSync(exe,args,opt){fs.cpSync(rawDir,opt.env.EVIDENCE_DIR,{recursive:true});const copy=structuredClone(r);copy.runner=sha(fs.readFileSync(path.join(d,path.basename(args.at(-1)))));fs.writeFileSync(path.join(opt.env.EVIDENCE_DIR,'results.json'),JSON.stringify(copy,null,2));if(p)p.runToken=opt.env.THIRD_RUN_TOKEN;copy.head=cp.execFileSync('git',['rev-parse','HEAD'],{cwd:repo,encoding:'utf8'}).trim();copy.tree=cp.execFileSync('git',['rev-parse','HEAD^{tree}'],{cwd:repo,encoding:'utf8'}).trim();fs.writeFileSync(path.join(opt.env.EVIDENCE_DIR,'results.json'),JSON.stringify(copy,null,2));if(p)fs.writeFileSync(path.join(opt.env.EVIDENCE_DIR,'third-policy-1.json'),JSON.stringify(p,null,2));else fs.unlinkSync(path.join(opt.env.EVIDENCE_DIR,'third-policy-1.json'));const manifest=Object.fromEntries(fs.readdirSync(opt.env.EVIDENCE_DIR).filter(f=>f!=='SHA256SUMS.json').map(f=>[f,sha(fs.readFileSync(path.join(opt.env.EVIDENCE_DIR,f)))]));fs.writeFileSync(path.join(opt.env.EVIDENCE_DIR,'SHA256SUMS.json'),JSON.stringify(manifest,null,2));return {status,signal:null,stdout:'SYNTHETIC RESULT FIXTURE: no browser run\n',stderr:''};}};
 let wrapper;try{vm.runInNewContext(fs.readFileSync(path.join(dir,'third-run.cjs'),'utf8'),{require:n=>n==='node:fs'?fsProxy:n==='node:child_process'?childProxy:n==='./third-audit.cjs'?auditor:require(n),__dirname:path.join(repo,'tests/select-webkit-timeline'),process:processMock,console:{log:v=>stdout.push(v)},Buffer});const result=JSON.parse(fs.readFileSync(path.join(d,'wrapper/third-results.json')));wrapper={exit:processMock.exitCode,status:result.status,complete:result.runs[0].complete,traceValid:result.runs[0].traceValid,auditReasons:result.runs[0].auditReasons,diagnosticFailures:result.diagnosticFailures};}catch(e){wrapper={threw:String(e),stdout};}
 const item={name,direct,wrapper};fs.writeFileSync(path.join(d,'outcome.json'),JSON.stringify(item,null,2));summary.push(item);
}fs.writeFileSync(path.join(dir,'counterexample-summary.json'),JSON.stringify(summary,null,2));console.log(JSON.stringify(summary,null,2));
