'use strict';
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),cp=require('node:child_process'),crypto=require('node:crypto');
const dir=__dirname,repo=path.resolve(dir,'../..'),audit=require('./third-audit.cjs').audit;
const raw=JSON.parse(fs.readFileSync(path.join(repo,'.work/final8-exact-chromium-direct/run-01/results.json')));
const trace=fs.readFileSync(path.join(repo,'.work/final8-exact-chromium-direct/run-01/third-trace-1.json'));
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const expected={head:raw.head,tree:raw.tree,runner:raw.runner,source:raw.source,ids:raw.rows.map(x=>x.id)};
const check=(r,n)=>r.rows[0].checks.find(c=>c.name===n);
const cases=[
 ['control-policy-stop',r=>{}],
 ...['environment','layout','Button','Badge','Alert','Switch','Tooltip','errors'].map(n=>['failed-'+n,r=>{check(r,n).pass=false;check(r,n).error='Error: independent injected '+n+' failure';delete check(r,n).detail;}]),
 ['missing-pass',r=>{for(const c of r.rows[0].checks)if(c.name!=='Select')delete c.pass;}],
 ['string-pass',r=>{check(r,'Switch').pass='false';}],
 ['missing-Tooltip',r=>{r.rows[0].checks=r.rows[0].checks.filter(c=>c.name!=='Tooltip');}],
 ['missing-errors-check',r=>{r.rows[0].checks=r.rows[0].checks.filter(c=>c.name!=='errors');}],
 ['duplicate-check',r=>{r.rows[0].checks.push({name:'Button',pass:false,error:'duplicate failure'});}],
 ['row-error',r=>{r.rows[0].error='Error: finally failed';}],
 ['unexpected-console',r=>{r.rows[0].console.push({classification:'unexpected',message:'unexpected exception'});check(r,'errors').pass=false;check(r,'errors').error='Error: unexpected console error';}],
 ['policy-substring-impostor',r=>{check(r,'Select').error='TimeoutError: diagnostic message mentions THIRD_POLICY_FORCED_CLICK_NOT_TESTED but this is a timeout';}],
 ['policy-no-paint',r=>{delete r.rows[0].selectPaint;r.rows[0].images=r.rows[0].images.filter(f=>!f.includes('-Select-'));}],
 ['policy-empty-events',r=>{r.rows[0].events=[];}],
 ['select-string-pass',r=>{check(r,'Select').pass='false';check(r,'Select').error='Error: Select real failure';}],
 ['status-contradiction',r=>{r.status='PASS';r.rows[0].status='PASS';}],
 ['exit-zero-contradiction',r=>{},0],
 ['null-row',r=>{r.rows=[null];}],
 ['null-check',r=>{r.rows[0].checks.push(null);}],
 ['wrong-checks-type',r=>{r.rows[0].checks={};}],
];
const summary=[];
for(const [name,mutate,status=1] of cases){
 const r=structuredClone(raw);mutate(r);const d=path.join(dir,'case-'+name);fs.mkdirSync(d);fs.writeFileSync(path.join(d,'results.json'),JSON.stringify(r,null,2));
 let direct;try{direct={reasons:audit(r,expected,{status})};}catch(e){direct={threw:String(e)};}
 const processMock={env:{...process.env,THIRD_LANE:'exact',THIRD_ENGINE:'chromium',THIRD_FOCUS:'direct',THIRD_REPEATS:'1',THIRD_OUT:path.join(d,'wrapper'),APP_ROOT:path.join(repo,'.work/v10')},execPath:process.execPath,version:process.version};
 const stdout=[];const fsProxy=new Proxy(fs,{get(t,k){if(k==='writeFileSync'||k==='unlinkSync')return (f,...args)=>t[k](String(f).includes('/.third-generated-')?path.join(d,path.basename(f)):f,...args);return t[k];}});
 const childProxy={...cp,spawnSync(exe,args,opt){const copy=structuredClone(r);copy.runner=sha(fs.readFileSync(path.join(d,path.basename(args.at(-1)))));fs.mkdirSync(opt.env.EVIDENCE_DIR,{recursive:true});fs.writeFileSync(path.join(opt.env.EVIDENCE_DIR,'results.json'),JSON.stringify(copy,null,2));fs.writeFileSync(path.join(opt.env.EVIDENCE_DIR,'third-trace-1.json'),trace);return {status,signal:null,stdout:'SYNTHETIC RESULT FIXTURE: no browser run\n',stderr:''};}};
 let wrapper;try{vm.runInNewContext(fs.readFileSync(path.join(dir,'third-run.cjs'),'utf8'),{require:n=>n==='node:fs'?fsProxy:n==='node:child_process'?childProxy:n==='./third-audit.cjs'?require('./third-audit.cjs'):require(n),__dirname:path.join(repo,'tests/select-webkit-timeline'),process:processMock,console:{log:v=>stdout.push(v)},Buffer});wrapper={exit:processMock.exitCode,stdout,result:JSON.parse(fs.readFileSync(path.join(d,'wrapper/third-results.json')))};}catch(e){wrapper={threw:String(e),stdout};}
 const item={name,direct,wrapper:wrapper.threw?wrapper:{exit:wrapper.exit,status:wrapper.result.status,complete:wrapper.result.runs[0].complete,traceValid:wrapper.result.runs[0].traceValid,auditReasons:wrapper.result.runs[0].auditReasons,diagnosticFailures:wrapper.result.diagnosticFailures}};
 fs.writeFileSync(path.join(d,'outcome.json'),JSON.stringify(item,null,2));summary.push(item);
}
fs.writeFileSync(path.join(dir,'counterexample-summary.json'),JSON.stringify(summary,null,2));console.log(JSON.stringify(summary,null,2));
