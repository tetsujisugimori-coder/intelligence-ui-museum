# Independent baseline audit review

Reviewed: 2026-11-07 18:10 JST. Baseline HEAD: `8e52ebe049a74abf9f6a9f91f855a12488980f32`. Reviewer did not modify tracked product, SDK, locks, original runner, or historical evidence. All work is new in this directory. Baseline diagnostic source snapshots are included.

## Findings

### P1: Required outcomes are not audited, so failed checks exit zero

`third-audit.cjs:10-12` only requires names and an empty row.errors array. It ignores pass type/value, row.error, duplicate checks, and all Tooltip/errors coverage. `third-run.cjs:43,53,59` turns the empty reasons list plus trace completeness into COMPLETE and exit zero. Independent single-field mutations of the real `final8-exact-chromium-direct/run-01/results.json` confirmed failed environment, layout, Button, Badge, Alert, Switch, Tooltip and errors checks; missing/string pass; missing Tooltip/errors; duplicate checks; row.error; and unexpected console errors all return no audit reasons and COMPLETE/exit0. Source/HEAD/tree/runner bindings remain valid and trace is the unchanged recorded full trace.

Require all nine check names exactly once; strict Boolean pass fields; successful non-Select checks; no row.error; empty page errors; explicit console evidence and errors-check validity. Validate consistency among row status, suite status and process exit. A suite exit1 is allowable only when all of its actual failures are the separately verified policy stop.

### P1: Policy exception can swallow unrelated Select failure

`third-run.cjs:48` exempts any Select error containing `THIRD_POLICY_FORCED_CLICK_NOT_TESTED`. An injected `TimeoutError: diagnostic message mentions THIRD_POLICY_FORCED_CLICK_NOT_TESTED but this is a timeout` produced COMPLETE/exit0. A string-valued Select.pass (`"false"`) likewise bypassed failure classification. Deleting the entire Select paint evidence still passed.

Require exact error identity/text and Select.pass === false, with a separate Node-side guard receipt bound to this run, page/row, operation and exact locator. Receipt must assert force:true was blocked before dispatch and appear exactly once. The known unchanged original runner reaches this guard only after its earlier Select assertions and ring checks; require those recorded prerequisites too. A receipt provides origin evidence that a bare substring cannot. Missing historical receipts must remain unverified, not be retroactively fabricated or treated as success. No extra browser actions or force click are needed to record a guard receipt before throwing.

### P2: Malformed JSON crashes wrapper before it records an audit outcome

`third-run.cjs:40` calls result.rows.map and row.checks.find/filter before validating structure. JSON with a null row, null check, or non-array checks made the wrapper throw TypeError and omit third-results.json. Direct audit also throws for null rows; a null check appended after valid checks is silently accepted by direct audit. Require defensive validation before projection and record malformed cases as INCOMPLETE/nonzero with explicit reasons.

### P3: Trace validation has weak final schema and is not total

`traceAudit({level:'none',final:true}, 'none')` returns no reasons. A full trace with final.triggerId = {} also returns no reasons. Null events and object-valued events throw. Wrapper catches trace exceptions but only exposes the generic invalid-file reason. These checks establish limited collection presence, not full condition/run provenance or Select completion. Do not describe them as product acceptance or strict trace proof. Trace geometry being offscreen must not itself be rejected because that is legitimate diagnostic data.

## Independent execution and evidence

- Baseline upstream unit suite: 22/22 pass. Captured stdout, stderr, exit. Its baseline good fixture has names without pass values, which shows why existing tests did not catch the issue.
- Counterexample script: 25 cases (one unchanged real-evidence control; 21 invalid mutations yielding COMPLETE/exit0; three wrapper TypeErrors). Script uses the frozen baseline wrapper source in a VM, real file/git/hash handling, and a stub only for browser child results. It does not claim to be 25 live browser runs. Each case preserves raw input JSON, wrapper raw JSON/trace, stdout and outcome. Summary: `counterexample-summary.json`.
- Trace schema probes: four cases saved in `trace-counterexamples.json`.
- Live browser attempts: two fresh exact Chromium direct 375/light/100 runs. Standard Playwright failed before opening a browser because chromium_headless_shell-1194 was absent. Existing /usr/bin/chromium failed at launch with socket() Operation not permitted and read-only crash-report configuration; SIGABRT. Both wrappers returned INCOMPLETE/nonzero and preserved logs. No GUI correctness was tested. No escalation, package/browser install, or security setting change was attempted.
- Changes currently being made by the implementer were not relied on. This is a baseline report, not approval of the repaired code. Independent re-review is still required.
