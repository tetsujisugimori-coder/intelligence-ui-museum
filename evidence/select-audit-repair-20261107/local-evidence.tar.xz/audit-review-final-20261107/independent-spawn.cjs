'use strict';
// Review-only: replace browser child with a real subprocess that replays an explicit fixture.
const cp=require('node:child_process'),path=require('node:path'),original=cp.spawnSync;
cp.spawnSync=function(exe,args,options){return original.call(this,process.execPath,[path.join(__dirname,'independent-child.cjs')],{...options,env:{...options.env,NODE_OPTIONS:''}});};
