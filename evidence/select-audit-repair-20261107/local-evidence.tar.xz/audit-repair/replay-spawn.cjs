const cp=require('node:child_process'),old=cp.spawnSync;
cp.spawnSync=function(exe,args,opts){return old.call(this,process.execPath,[process.env.REPLAY_CHILD],opts);};
