const fs=require('fs'),path=require('path');
const src=process.env.REPLAY_SOURCE,dest=process.env.EVIDENCE_DIR;
fs.cpSync(src,dest,{recursive:true});
const file=path.join(dest,'results.json'),r=JSON.parse(fs.readFileSync(file)),row=r.rows[0],find=n=>row.checks.find(c=>c.name===n);
switch(process.env.REPLAY_CASE){
case 'Button-false': find('Button').pass=false; find('Button').error='injected Button failure';break;
case 'environment-false':find('environment').pass=false;find('environment').error='injected environment failure';break;
case 'missing': row.checks=row.checks.filter(c=>c.name!=='Button');break;
case 'duplicate':row.checks.push(structuredClone(find('Button')));break;
case 'status-contradiction':row.status='PASS';break;
case 'unexpected-select':find('Select').error='Error: unexpected select failure';break;
case 'substring':find('Select').error='Error: unrelated failure includes THIRD_POLICY_FORCED_CLICK_NOT_TESTED suffix';break;
}
fs.writeFileSync(file,JSON.stringify(r,null,2));
process.exitCode=process.env.REPLAY_CASE==='exit-contradiction'?0:1;
