# Incomplete trace accepted by HEAD 7e58e2d

2026-11-07 JST. This finding supersedes the earlier limited local sign-off for the additional incomplete-trace acceptance boundary. Existing review reports and historical evidence are unchanged.

At HEAD 7e58e2dcbdd7b8adc92076abd8a2347928fbdd8d, independently executed Chromium minimal/legacy 375/light/100 to a new live-minimal directory. This was a real browser run, with diagnostic COMPLETE/exit0 and original child exit1, recording the blocked policy action as NOT_TESTED.

Next, independent real-subprocess wrapper replays used that raw fixture. A control accepted normally. The negative fixture changes only third-trace-1.json final to true, then regenerates the evidence manifest. The replay harness intentionally refreshes HEAD/tree and invocation nonce consistently for each run; it does not claim to be a fresh browser run. Both real wrapper processes return COMPLETE/exit0, traceValid:true and no audit or trace reasons. Thus the primitive final is accepted at the wrapper boundary, not merely by an isolated helper.

Evidence: control.outcome.json, final-true.outcome.json, both wrapper directories, stdout/stderr and fresh live-minimal raw evidence. Executed audit SHA256: 269b09f92763363804ae510539b756bd27e10b202a9476a6c97ddb7c48c56bee.

Recommended repair: require an object final with finite scrollY, Boolean hasFocus, and a string active for the none lane. Do not require final trigger geometry to be in the viewport: the original runner subsequently tests Tooltip and legitimately scrolls away from Select.
