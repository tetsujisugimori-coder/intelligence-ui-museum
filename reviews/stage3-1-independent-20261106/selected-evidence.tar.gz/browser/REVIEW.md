# 独立担当B: Stage 3-1 v10 browser review

2026-11-06 03:13 JST。固定対象 `401c554ae87a6d846b1655bc9af12a92d7002633`。Debian 13、Playwright 1.56.1、system Chromium `154.0.8037.57` (`/usr/bin/chromium`)。製品・原テスト・既存証拠は無変更。独立作成したPlaywright probeによるマウス/キーボードの自動ブラウザ操作。物理マウス/実機タッチ、実機Safari、VoiceOver、native文字拡大ではない。

## 判定

**ブラウザ担当総合 FAIL / 研究版受入推奨 NO**。正常フォーカスの旧未確認条件はChromiumに限り確認できたが、公式Select閉鎖後のフォーカス復帰が失敗する新規P2候補を確認。WebKit新規実行はブラウザ導入先のネットワークpolicy拒否によりNOT_TESTED（親担当が導入失敗原票を保持）。成功した既存CIを独立WebKit実行へ換算していない。

## 正常focus、重点2条件、負対照

- `focus-only/results.json`: Chromium 320/375/390/1280 × light/dark × synthetic root100/200 = **16/16正常**。各条件ButtonとSelectへfocus→Tab→Shift+Tabで到達し、activeElement、focus-visible、computed outline/pseudo geometry、ancestor clip、ON/OFF/RETURN PNGを収集。root fontと横超過も記録。viewport横超過0、pageerror0。
- 重点 `320 dark root200` と `1280 light root100` の正常は両方確認。Buttonは橙と青、Selectは青の枠がPNG上で描画され、抑止時に消え復帰時に戻ることを目視。`focus-clipped4/qa-sheet.png` の20 cropも目視。
- 独自pixel判定は製品の状態判定を正解に再利用しない。同じ領域を枠ON/OFF/RETURNでPNG比較し、RGB最大差24以上の反復差、ON/RETURN安定差8以内、最低変化画素 max(16,(幅+高さ)/2)を要求。一般的WCAG完全適合、任意CSS、全ての部分クリップを保証しない。
- 最初の `clip-path:inset(0)` は内側の枠が残り、4/8しか拒否されず **focus-onlyのprocess exit1**。これは故障が全枠消失に至らなかった対照設計の誤りで、製品欠陥や検査器偽PASSと判定しない。原データは保全。
- `focus-clipped4` の正しい全枠消失対照 (`clip-path:inset(4px round 999px)`) と枠消去を、重点2条件×Button/Selectで新規実行。正常2/2、消去/clip **8/8を拒否**。新probeの **exit0**。PNG上でも正常枠の存在と故障時の消失を確認。

## 6部品と行列

`independent.cjs/results.json` は16条件を新規実行、WebKit launch失敗1記録を別に含む。正常完走PASSと呼ばない（**exit1**）。

- Button: click/Enter/Spaceで実行回数3、disabled時不変、loading時disabledと出力整合 **16/16成功**。focusも16/16。
- Select: accessible name、mouse選択、keyboard Space/Arrow/Enter選択とhidden input値 **16/16成功**。Tab/Shift+Tabで取得したfocus枠も16/16成功。**確定後focus復帰16/16失敗、Escape後focus復帰16/16失敗**。
- Badge: danger表示・variants **16/16成功**。追加components probeのsuccess/warning/danger3色も16/16。
- Switch: 初期OFF、click ON、Space OFF、output/aria整合、disabled **16/16成功**。
- Alert: 原matrix11/16が閉鎖・Enter再表示・warning出力まで成功。残5条件は先行Tooltip未完了により到達せず。追加 `components/results.json` により閉鎖・Enter再表示・dangerの**16/16成功**を独立確認。
- Tooltip: 原matrixは11/16でTab/Shift+Tab到達・表示・Escape保持・hover成功、5/16は先行scroll/focus操作後のpopup待ちがtimeout。これだけで製品P2と断定しない。fresh直接focusでは重点2/2で説明表示。`tooltip-stable` はpending scroll配送を2 RAFで待ち、対象直前にtemporary DOM sentinelを挿入して実Tabで到達。active/focus-visible、説明テキスト、Escape閉鎖とtrigger保持を **16/16成功 exit0**、focusin履歴/PNGあり。これは部品への局所的keyboard到達を確認したもので、実ページ先頭から全Tab順序を通過した保証ではない。初回selectorがsentinelにも一致したharness errorも原票保全、成功件数に含めない。
- `components` 自体はscroll直後Tooltip focus16/16失敗を残すため **exit1**。非Tooltip部分は16/16成功。Tooltip scroll/focus順依存の詳細原因はUNKNOWN。
- `layout/results.json`: 公式6部品のpane内文字rangeとclip祖先、control viewport bounds、document横幅を16条件で新規比較し **16/16成功 exit0**。hidden details/sr-onlyは除外。これを全描画・全ラベルのピクセル完全適合とは呼ばない。
- JS pageerrorは保存した新規条件で0。console errorには既知KaTeX font-src CSP拒否20件があり、無エラーと偽らず、その他console errorから分離した。既存公開HOLD事項を維持。

## P2候補 S3-1-SELECT-RETURN

最小反例 `front-check/focus-return.cjs` / JSON / PNG。重点2条件それぞれfresh page→bringToFront→Select triggerへfocus、Tab/Shift+Tab→Spaceでmenuへfocus→ (a)mouseでカード、(b)ArrowDown/Enterでカード、(c)Escape閉鎖。option hidden後も最大2秒の状態待ちを行い、trigger復帰を待つ。

**6/6で閉鎖後document.activeElementはBODY**。閉鎖前はtrigger SPAN、メニュー中はDIV。document.hasFocus=true、visibilityState=visibleを維持。値はa/bで正しい。続くTabでもtop documentはBODYの記録で、triggerへ復帰したと判定できない。`minimal.json` のfocusin履歴にも閉鎖後trigger復帰はない。通常行列16条件でも同症状。

原因候補: 固定公式SDK0.2.2 `dist/es/components/Select/Select.js` のCustomSelect.handleOpenChangeは閉鎖時setTimeoutで復帰を試みるが、selectContentRef.currentがnullならreturnする。同ファイルのTransitionGroupはdisableAnimations:trueで、close後のmenu除去でrefが先に消える経路と整合。候補であり製品を編集して根因確定してはいない。アクセシビリティ名の不足や旧active=falseのfocus描画誤判定とは別問題。

修正条件: 固定0.2.2の研究展示方針に沿った局所的な復帰補助または既知公式挙動の扱いを別branch/PRで検討し、mouse確定・keyboard確定・Escapeそれぞれ閉鎖後triggerへ復帰しfocus-visibleを検証する。対象HEAD証拠は保持。依存更新・公式本体改造は今回行っていない。

## 実測終了値

- `independent.cjs`: 1
- `focus-only/focus.cjs`: 1 (inset0対照の期待誤り、正常16/16)
- `focus-clipped4/focus.cjs`: 0 (正常2/2、負対照8/8検出)
- `focus-return.cjs`: 1
- `front-check/focus-return.cjs`: 1
- `components/check.cjs`: 1 (非Tooltip16/16成功、Tooltip scroll後focus失敗を保持)
- `tooltip-stable/check.cjs`: 0 (16/16)
- `layout/check.cjs`: 0 (16/16)

最初のmain runは検査手順改善のため中断し `initial-run/` に保全。成功runに混入していない。製品修正、commit/push、GitHub投稿はこの担当では実施せず統合担当へ委譲。

## 再現コマンド

親担当が作成した隔離 `.work/v10` のbuildと `tools/stage-a-browser/node_modules` を使用。Playwright1.56.1固定、system Chromium経路は上記。HTTPサーバを別ターミナルで起動:

```sh
python3 -m http.server 8775 --bind 127.0.0.1 --directory /workspace/ium-independent/.work/v10/dist
```

各probeは `/workspace/ium-review-evidence/browser/` 配下の新しい未使用コピーへ保存し、該当Node scriptを実行する。`independent.cjs`、`focus-only/focus.cjs`、`focus-clipped4/focus.cjs`は自前のlocalhost ephemeral portサーバを起動する。他probeは8775を使用。source内のROOT/OUT pathはこの独立環境の絶対pathで、移設時は検査コピーの対応箇所だけを変更する。元の固定対象ソースを変更しない。

```sh
node /workspace/ium-review-evidence/browser/independent.cjs
node /workspace/ium-review-evidence/browser/focus-only/focus.cjs
node /workspace/ium-review-evidence/browser/focus-clipped4/focus.cjs
node /workspace/ium-review-evidence/browser/front-check/focus-return.cjs
node /workspace/ium-review-evidence/browser/components/check.cjs
node /workspace/ium-review-evidence/browser/tooltip-stable/check.cjs
node /workspace/ium-review-evidence/browser/layout/check.cjs
```
