# 担当C：Stage A 検証器・故障検出の独立実行

2026-11-06 03:12 JST（実行日時の厳密値は各JSONのUTC値）。対象HEAD `401c554ae87a6d846b1655bc9af12a92d7002633`。対象treeと全scriptのrepo/.work SHA-256一致は`source-identity.json`。製品と原runnerを変更していない。すべての新証拠はrepo外の本ディレクトリへ保存。既存証拠不変。独立担当Cは実装に参加していない。

**T6担当判定：PARTIAL。** Chromiumで今回の故障状態を検出すること、synthetic契約で正常0・故障1を独立再現できた。新規WebKitはCDNポリシー拒否／実行ファイル欠落のためBLOCKED。両engineを要求する原browser entryの通常exit0・負対照exit1の組は新規実行できず、環境失敗exit1を負対照成功へ読み替えていない。既存CIのWebKit成功を自身の新規実行としない。

## 環境と原entry

Linux x86_64、Node v24.19.0、固定Playwright1.56.1、system `/usr/bin/chromium` 154.0.8037.57。Playwright固定Chromiumではない。WebKit `webkit-2215/pw_run.sh` 不在。root担当がPlaywrightダウンロード403 Domain forbiddenを保存し、私は迂回していない。

`run-original.cjs`が`.work/v10`で未変更`stage2r-browser-acceptance.cjs`を1ケースずつ起動する。環境は`CODEX_PRIMARY_RUNTIME_NODE_MODULES=/workspace/ium-independent/tools/stage-a-browser/node_modules`、`CHROMIUM_EXECUTABLE=/usr/bin/chromium`、`EVIDENCE_DIR=<本dir>/original/<case>`、`ACCEPTANCE_CASES=<case>`。子runner/外側acceptanceのexit・時刻・生JSON・stdout/stderr・PNGを保存。原sourceは全てrepoとbyte一致。

| 原ケース | 新規Chromiumの実状態 | 子exit / 外側exit | 解釈 |
|---|---|---|---|
| normal-smoke | 6条件正常、v09各4幅・公式6部品・noJS117 | 1 / 1 | WebKit欠落、全体BLOCKED |
| normal-matrix | 24条件全check成功。root16＋CDP font8 | 1 / 1 | WebKit欠落、全体BLOCKED |
| modal-delayed | 150ms遅延後の閉鎖/復帰、Chromium6条件成功 | 1 / 1 | WebKit欠落、全体BLOCKED |
| modal-stuck | Chromium4幅全てwaitForFunction Timeout5000ms | 1 / 1 | 故障状態検出。全体exitは環境混在 |
| focus-missing | Chromium24全てSelect focusだけFAIL、changed0 | 1 / 1 | 故障状態検出。全体exitは環境混在 |
| focus-hidden | Chromium24全てSelect focusだけFAIL、changed0 | 1 / 1 | 同上 |
| focus-clipped | Chromium24全てSelect focusだけFAIL、changed0。active/focus-visible/computed paintedは全てtrue、他check全成功 | 1 / 1 | style-only偽GREEN条件を描画比較で拒否。全体exitは環境混在 |
| late-pageerror | ChromiumのJS有効5条件全てclose直前pageerrorを記録 | 1 / 1 | 後着errorを保持。全体exitは環境混在 |
| cleanup-failure | 最初のChromium context cleanupで例外、不完全1条件reportを拒否 | 1 / 0 | 意図した故障をacceptanceが確認。WebKit未到達 |
| runner-timeout | 意図的1ms process deadline、ETIMEDOUT、子status null | null / 0 | deadline対照成功。自然発生timeoutやOS crashではない |

詳しくは`summary.json`、`original-runs.json`、各`original/<case>/acceptance.json`。24条件は32条件と呼ばない。root font200とCDP font設定はOS/実機のnative文字拡大と呼ばない。入力はPlaywrightのpointer/keyboard/touch APIで、物理機器操作ではない。

重点2条件（320 dark root200／1280 light root100）の正常/clip `focus-...-on.png`を本担当がview_imageで確認した。正常の青い枠はclipで完全に消失するが、文字・矢印は残る。画素数は正常1240〜2439、各消失対照0。style-only painted=trueで見逃すclipを検出する経路を確認した。任意CSSやWCAG完全適合の保証ではない。

## 既存25契約と独自8反例

`.work/v10`で`node --test scripts/stage2r-runner.test.cjs`を実行。25/25成功・exit0・skip0。`unit.log`/`unit.exit`保存。

独自`acceptance-contract-probe.cjs`は、原acceptance entry自体を同一realmで実行し、child_processだけを独立生成した12条件smoke fixtureへ置換する（ブラウザではない）。正解チェック名は手書きし製品の判定関数から生成していない。正常fixture exit0、結果ファイル欠落・JSON切断・未完走・11/12条件・valid report/子exit1・FAIL report/子exit0・JS errors非空の7反例は全て外側exit1。`contract-*.exit/log`と`contract/<case>/`保存。子成功だけでPASSにならないことを原acceptanceで確認。

追加で実smoke entryの保存処理だけを失敗させるcontrolled model `SAVE_FAILURE=1 node scripts/stage2r-smoke-fault-probe.cjs`を実行し、例外伝播・exit1・証拠capture0を確認（`save-failure.*`）。

## 旧→新 RED/GREEN

旧Git commit `8bb1965`から**runnerとvalidator両方**をexact blobとして`old-app/scripts`へ取り出す。同じ現行controlled browser model probeを旧/新に与えた。正常は旧0/新0、Alert再表示失敗は旧0/新1、公式6部品pageerrorは旧0/新1。各12条件capture。これは実ブラウザでなくsynthetic browser modelでの原entry exit比較。`old-pair-*.log/exit`と`new-*.log/exit`保存。

さらに独自の実Chromium shim（`independent-module/playwright/index.js`）で、(1)Alertの2回目の実clickをcapture段階で遮断、(2)Button実click後にpageerrorを発生させた。同じ現行dist・同じshimを旧/新に適用した。

- Alert: 別observerで旧/新とも再表示後に`通知表示：非表示`、alert DOM不在を確認。旧runnerは六部品をPASSとして誤採用、新runnerはalert-demo可視assertでFAIL。正常対照は両方表示中/DOM存在/PASS。
- pageerror: 別observerで旧/新とも`independent Button click pageerror`の実発生時刻を記録。旧runnerの六部品はPASS・error記録なし。新版は六部品status自体はPASSだがerrors配列へ保持し、validatorが拒否する。
- この実ブラウザ比較では旧/新とも最後にWebKit欠落でentry exit1。従って全体exitのRED→GREENと偽っていない。Chromiumの実障害状態と原assert/recordの差、および上記syntheticのclean exit比較を別々に報告。

`observed-runs.json`、`{old,new}-observed-{normal,alert-reopen,pageerror}/smoke.json`、別observer JSON、PNG、stdout/stderrを保存。正常/Alert故障PNGを本担当が目視し、正常のdanger通知＋表示中と故障の通知欠落＋非表示を照合した。fullPageのlazy v09 iframe空欄は別の話で、117展示の操作欠落の証拠として用いていない。

## 所見と限界

新規P1/P2/P3は確認していない。旧Alert/pageerrorの偽PASSは固定HEADで改善を再現し、現在の製品障害とは扱わない。既知Issue#9の信頼外rootにおける逐次TOCTOUは未修正、信頼された隔離root/127.0.0.1限定で使用。Issue#10はv11のPASS/error合成矛盾で別対象、今回のv10修正済みと主張しない。新規WebKit全条件、実機Safari/VoiceOver/native文字拡大、自然発生OS timeout/crashはNOT_TESTED/UNKNOWN。

探索段階の無効な混合version試験・VM cross-realm normal誤拒否は`exploratory/`に失敗のまま保存し、成功件数/RED→GREENに含めていない。最終probeは正常exit0を前提対照として成立させた。

この担当の検証だけでS3-1研究版受入YESを推奨しない。WebKitを含む不足を独立実行で補う必要がある。文書PR限定のマージ可否は統合担当が別判定する。Stage3 HOLD維持、製品修正・公開・merge操作なし。
