// Independent adversarial fixture for the unmodified acceptance entry, no browser.
const fs=require('fs'),path=require('path'),vm=require('vm'),{createRequire}=require('module');
const name=process.argv[2], base='/workspace/ium-independent/.work/v10/scripts/stage2r-browser-acceptance.cjs', local=createRequire(base), out=path.join(__dirname,'contract',name);
fs.mkdirSync(out,{recursive:true});
const normalChecks=['117 rendered cards','search, category switching','theme','Modal open/Escape','Primary and Select interactions (3 exhibits including Modal)'];
const sixChecks=['Badge','Switch','Tooltip visible on hover and hidden after Escape','Alert color/close/reopen','already-loaded offline Button'];
const report={finished:'independent fixture',failures:[],conditions:['chromium','webkit'].flatMap(engine=>[...[320,375,390,1280].map(width=>({engine,width,errors:[],status:'PASS',checks:[...normalChecks]})),{engine,sixComponents:true,errors:[],status:'PASS',checks:[...sixChecks]},{engine,noJS:true,cards:117,errors:[]}])};
let childExit=0;if(name==='unfinished')delete report.finished;if(name==='incomplete')report.conditions.pop();if(name==='exit1-valid')childExit=1;if(name==='exit0-fail')report.conditions[0].status='FAIL';if(name==='js-error')report.conditions[0].errors.push('independent unexpected error');
const real=local('node:child_process');
const context={require:n=>n==='node:child_process'?{...real,spawnSync:(_exe,_args,opts)=>{const dir=opts.env.EVIDENCE_DIR;fs.mkdirSync(dir,{recursive:true});if(name!=='missing')fs.writeFileSync(path.join(dir,'smoke.json'),name==='truncated'?'{"conditions":':JSON.stringify(report));return {status:childExit,stdout:'fixture child',stderr:'',signal:null}}}:local(n),process:{...process,env:{...process.env,CODEX_PRIMARY_RUNTIME_NODE_MODULES:'/fixture/not-executed',EVIDENCE_DIR:out,ACCEPTANCE_CASES:'normal-smoke'},get exitCode(){return process.exitCode},set exitCode(v){process.exitCode=v}},console,URL};
vm.compileFunction(fs.readFileSync(base,'utf8'),['require','process','console','URL'])(context.require,context.process,context.console,context.URL);
