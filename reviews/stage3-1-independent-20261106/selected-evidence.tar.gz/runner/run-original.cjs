const fs=require('fs'),path=require('path'),cp=require('child_process');
const out=__dirname, app='/workspace/ium-independent/.work/v10';
const rec=[];
for(const name of ['normal-smoke','normal-matrix','modal-delayed','modal-stuck','focus-missing','focus-hidden','focus-clipped','late-pageerror','cleanup-failure','runner-timeout']) {
 const dir=path.join(out,'original',name);fs.mkdirSync(dir,{recursive:true});const started=new Date().toISOString();
 const r=cp.spawnSync(process.execPath,['scripts/stage2r-browser-acceptance.cjs'],{cwd:app,env:{...process.env,CHROMIUM_EXECUTABLE:'/usr/bin/chromium',CODEX_PRIMARY_RUNTIME_NODE_MODULES:'/workspace/ium-independent/tools/stage-a-browser/node_modules',EVIDENCE_DIR:dir,ACCEPTANCE_CASES:name},encoding:'utf8',timeout:300000,maxBuffer:16*1024*1024});
 fs.writeFileSync(path.join(dir,'outer.stdout.log'),r.stdout||'');fs.writeFileSync(path.join(dir,'outer.stderr.log'),r.stderr||'');
 rec.push({name,started,finished:new Date().toISOString(),outerExit:r.status,signal:r.signal,error:r.error?.message});fs.writeFileSync(path.join(out,'original-runs.json'),JSON.stringify(rec,null,2));console.log(name,r.status);
}
