# 歴史distと新規buildの差：原因調査

2026-11-06 03:17 JST。原distは変更していない。

**結論：製品ソースや依存platformの差ではなく、追加された検証scriptをTailwind 4の自動source scannerが拾うため。**

1. 歴史distと新規buildのmapは89件のsources/sourcesContent/names/mappingsがすべて一致。唯一の差は生成JSファイル名。JS本文もsourceMappingURLのファイル名以外はbyte一致した。
2. CSSの差は新規utility `.transform\!`、`.ring`、`.filter\!` の3個・571 bytesの追加だけ。旧145,468 bytes、新146,039 bytes。
3. 現行`stage2r-focus-pixels.cjs`には `s.transform!=='none'` と `s.filter!=='none'`、runnerのコメント等には単語`ring`がある。`src/main.css`はTailwindをimportし、scan範囲を製品srcだけに限定していない。
4. 独立copy `/tmp/ium-scan-probe` で、現行src/publicと同じinstalled依存を維持し、scriptだけ初期取り込みcommit `8bb1965` の7ファイルに戻してbuild。実測exit0。
5. この対照のCSSは歴史distとbyte一致：SHA-256 `89fd3282b11361b3a0d7e70fd8b56812c7f065a056310daf09d199b5090730ce`。JSも歴史`index-ItwAwdWS.js`とbyte一致：SHA-256 `81d41645e10abe47487fcd714c4e91280351f8973b1a66b21d7f5e1d93076b23`。index.htmlほかpublic出力も一致した。
6. 対照mapのみ、node_modulesを元の新規installへsymlinkしたため相対sourceパスが異なる。sourcesContent/names/mappingsは一致。この差を製品code差としない。

補助対照としてscriptsを全除外すると、上記3個に加え旧script由来の`.sticky`と`.!container`も消え、歴史CSSより448 bytes小さくなった。全除外結果を「歴史dist再現」と誤認せず、初期script7件へ戻した対照で原因を絞った。

生証拠：`dist-source-comparison.json`、`dist-css-comparison.json`、`scan-probe-build.log`、`scan-probe.json`、`scan-original-scripts-build.log`、`scan-original-scripts.json`、`scan-original-scripts-all-dist.json`。

現行固定HEADの新規2build一致と、歴史distとのbyte一致は別の性質。後者を今回達成したと書かない。検証用scriptが製品CSS出力へ影響するsource scan境界は後続の保守改善候補だが、これだけで表示不具合やT2失敗と断定しない。追加utilityの画面影響はブラウザ担当の実測と別途評価する。
