# 独立担当A：T1 原本保全・SDK出自

確認日時：2026-11-06 03:08 JST。担当は製品実装に不参加。製品・原テスト・歴史証拠を変更していない。

判定：**PASS（静的保全・出自に限定）**。ビルド2回・ブラウザ・runner故障検出は別担当であり、本判定から実操作成功を推定しない。

- 固定HEAD `401c554ae87a6d846b1655bc9af12a92d7002633`、tree `e1f1604a8db5d62d5c713407f30511bb8ab5e30f`。
- clone時のmain/base/merge-baseはいずれも `aa744be94e0e03efb31439f339361ccc859ad656`。main比0 behind/1 ahead、変更は受入計画文書1ファイル追加92行のみ。製品・過去証拠のPR差分なし。
- v09は293,948 bytes、SHA-256 `327aec2c8e68479fd8c8dae51e0e5fc958c1db311dd12e9fafd06e3379cd7c97`。117連番ID・117固有名称・11分類、public/distの原本コピーbyte一致。viewer全dataset一致、v08先頭105件ID/名称/分類一致。
- 既存verify-migrationの実行結果に頼らず、独自PythonとGit showで原bundleの302ファイル、取り込み歴史証拠・baseline等252ファイル、archive/review台帳58ファイルを個別SHA-256比較。不一致0。
- package/lockは `@openai/apps-sdk-ui@0.2.2` を固定。公式6 importを製品ソースから確認し、npmパッケージのwildcard exportsと6部品の実ファイルの対応を確認。
- npm registryからfresh tgzを取得：1,092,414 bytes、2,645 files、SHA-256 `4bd4f51bc299e373278d62e4add789d84de483ca51a87fa6cec1398bc870a288`。SHA-512 integrityは固定lockと完全一致。registry gitHead `0f00143c7a639906f1621fe58e1b6be7b5bea46d` は6件provenanceと一致。registry repositoryは公式 `openai/apps-sdk-ui`。
- freshパッケージ2,645ファイルは`.work/v10/node_modules`と全byte一致。追加658ファイルは`node_modules/radix-ui/...`等の入れ子依存配置で、SDKパッケージ本体の改変ではない。
- 新規buildのJS map中SDK配下38 sourcesContentは、公式本体27がfresh tgz、入れ子依存11がinstalledファイルとbyte一致。
- 対象文書は研究版/公開版/v11を区別し、過去のPARTIALと後続PR #7の修正履歴を区別している。過去レビューのHEAD `66032de7...` を今回の対象とはしていない。T1範囲で新規P1/P2/P3を確認しなかった。

## 再現と生証拠

`python3 /workspace/ium-review-evidence/preservation/check.py > /workspace/ium-review-evidence/preservation/check.log` は実測exit0。JSONは `summary.json`、`bundle-results.json`、`protected-files.json`、`v09-identities.json`、`sdk/fresh-files.json`、`sdk/bundle-sources.json`。fresh取得は下記実測exit0。

```sh
npm pack @openai/apps-sdk-ui@0.2.2 --ignore-scripts --cache /tmp/ium-independent-npm-cache --pack-destination /workspace/ium-review-evidence/preservation/sdk --json
npm view @openai/apps-sdk-ui@0.2.2 gitHead repository dist --json --cache /tmp/ium-independent-npm-cache
```

最初のpackはdefault cache `/home/agent/.npm` のmkdir ENOENTでexit1。書込み可能な`/tmp` cache指定後に成功。最初の独自プローブはpackage exportsのwildcardを直接のキーと取り違えてassert失敗exit1。公開`./components/*`を展開し実ファイルの存在を確認する検査へ訂正した。いずれも製品不具合、負対照成功として扱っていない。

## 限界

署名・SLSA attestationの暗号検証はNOT_TESTED。npm registry取得物とlock integrity、registry gitHead、installed byte、build mapの一致までを確認した。最新依存監査、ライセンス残件の閉鎖、公開CSP・実配信、Safari/VoiceOver、全117展示の操作成功は本担当の対象外。Stage 3 HOLDを維持する。
