from pathlib import Path
import base64, datetime, hashlib, json, platform, re, subprocess, tarfile, tempfile

root = Path('/workspace/ium-independent')
out = Path(__file__).resolve().parent
def git(*args):
    return subprocess.check_output(['git', '-C', str(root), *args], text=True).strip()
def sha(data):
    return hashlib.sha256(data).hexdigest()
def parse(data):
    return json.loads(re.search(rb'<script[^>]*id="dataset"[^>]*>([\s\S]*?)</script>', data)[1])
original = (root / 'legacy/v09/index.html').read_bytes()
items = parse(original)
manifest = json.loads((root / 'docs/import-manifest.json').read_text())
archive = json.loads((root / 'docs/archive-manifest.json').read_text())
protected = []
for row in manifest['files']:
    source = row['source_path'].removeprefix('source/')
    if source.startswith(('evidence/', 'baseline/')) or source == '.openai/hosting.json':
        protected.append({'path': row['path'], 'expected': row['sha256'], 'actual': sha((root/row['path']).read_bytes())})
archive_results = [dict(path=row['path'], expected=row['sha256'], actual=sha((root/row['path']).read_bytes())) for row in archive]
bundle_results = []
with tempfile.TemporaryDirectory(prefix='ium-original-') as temp:
    subprocess.run(['git','clone','--bare','--quiet',str(root/'archive/stage2r2/stage2r2-history.bundle'),temp+'/history.git'],check=True)
    for row in manifest['files']:
        source = row['source_path'].removeprefix('source/')
        data = subprocess.check_output(['git','--git-dir='+temp+'/history.git','show',manifest['upstream_git']['head']+':'+source])
        bundle_results.append(dict(path=source, expected=row['sha256'], actual=sha(data)))
pack = json.loads((out/'sdk/pack.json').read_text())[0]
tgz = out/'sdk'/pack['filename']
lock = json.loads((root/'apps/v10/package-lock.json').read_text())['packages']['node_modules/@openai/apps-sdk-ui']
integrity = 'sha512-'+base64.b64encode(hashlib.sha512(tgz.read_bytes()).digest()).decode()
metadata = json.loads((out/'sdk/registry-metadata.json').read_text())
with tarfile.open(tgz) as tar:
    fresh = {m.name.removeprefix('package/'): sha(tar.extractfile(m).read()) for m in tar.getmembers() if m.isfile()}
    package = json.loads(tar.extractfile('package/package.json').read())
source = (root/'apps/v10/src/main.tsx').read_text()
provenance = json.loads((root/'apps/v10/docs/provenance.json').read_text())
exports = []
for row in provenance:
    name = row['component']
    mapping = package['exports']['./components/*']
    paths = {key: value.replace('*', name).removeprefix('./') for key, value in mapping.items()}
    exports.append(dict(component=name, importPresent=row['import'] in source, exportPaths=paths, exportFilesPresent=all(p in fresh for p in paths.values())))
installed = root/'.work/v10/node_modules/@openai/apps-sdk-ui'
installed_results = {'status': 'NOT_TESTED'}
if installed.exists():
    found = {str(p.relative_to(installed)): sha(p.read_bytes()) for p in installed.rglob('*') if p.is_file()}
    installed_results = dict(status='PASS' if all(found.get(k)==v for k,v in fresh.items()) else 'FAIL', files=len(fresh), mismatches=[k for k,v in fresh.items() if found.get(k)!=v], extra=sorted(set(found)-set(fresh)))
old = parse((root/'apps/v10/baseline/v08.html').read_bytes())
identity = lambda rows: [(x['id'],x['name'],x['category']) for x in rows]
summary = dict(executedAtJST=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9))).isoformat(), environment=dict(os=platform.platform(), python=platform.python_version()), head=git('rev-parse','HEAD'), tree=git('rev-parse','HEAD^{tree}'), base=git('rev-parse','origin/main'), mergeBase=git('merge-base','HEAD','origin/main'), aheadBehind=git('rev-list','--left-right','--count','origin/main...HEAD'), diff=git('diff','--numstat','origin/main...HEAD'), v09=dict(bytes=len(original), sha256=sha(original), count=len(items), idsSequential=[x['id'] for x in items]==list(range(1,118)), names=len({x['name'] for x in items}), categories=len({x['category'] for x in items}), copiesEqual={p:(root/p).read_bytes()==original for p in ['apps/v10/public/v09-original.html','apps/v10/dist/v09-original.html']}, viewerDatasetExact=parse((root/'apps/v10/public/v09-viewer.html').read_bytes())==items, v08First105Exact=identity(old)==identity(items[:105])), protected=dict(count=len(protected), mismatches=[x for x in protected if x['actual']!=x['expected']]), archive=dict(count=len(archive_results), mismatches=[x for x in archive_results if x['actual']!=x['expected']]), bundle=dict(count=len(bundle_results), mismatches=[x for x in bundle_results if x['actual']!=x['expected']]), sdk=dict(version=lock['version'], packagePin=json.loads((root/'apps/v10/package.json').read_text())['dependencies']['@openai/apps-sdk-ui'], tarballBytes=tgz.stat().st_size, tarballSha256=sha(tgz.read_bytes()), tarballFiles=len(fresh), integrity=integrity, integrityMatchesLock=integrity==lock['integrity'], registryGitHead=metadata['gitHead'], provenanceGitHeadMatches=all(x['source_commit']==metadata['gitHead'] for x in provenance), exports=exports, installed=installed_results))
(out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
(out/'bundle-results.json').write_text(json.dumps(bundle_results,indent=2))
(out/'protected-files.json').write_text(json.dumps(protected+archive_results,indent=2))
assert summary['v09']['count']==117 and summary['v09']['categories']==11 and summary['v09']['idsSequential']
assert all(summary['v09']['copiesEqual'].values()) and summary['v09']['viewerDatasetExact'] and summary['v09']['v08First105Exact']
assert all(not summary[k]['mismatches'] for k in ['protected','archive','bundle'])
assert summary['sdk']['integrityMatchesLock'] and summary['sdk']['provenanceGitHeadMatches']
assert all(row['importPresent'] and row['exportFilesPresent'] for row in exports)
print(json.dumps(summary,ensure_ascii=False,indent=2))
